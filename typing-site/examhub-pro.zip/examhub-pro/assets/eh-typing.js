/* Exam Hub Typing — exam-style typing window */
(function () {
  'use strict';
  var CFG = window.EH_TEST;
  if (!CFG) return;
  var H = window.EHHindi;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('eh_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('eh_' + k, JSON.stringify(v)); } catch (e) {} }
  };

  var exam = CFG.exam;
  var isHindi = exam.lang === 'hi';
  var LAYOUTS = isHindi
    ? [['krutidev', 'Hindi - Krutidev', 'Remington', 'Hindi - Krutidev Regular'], ['inscript', 'Hindi - Inscript', 'Inscript', 'Hindi - Mangal Font'], ['remington', 'Hindi - Remington Gail', 'Remington Gail', 'Hindi - Mangal Font'], ['external', 'Hindi - Inscript (own keyboard)', 'Inscript', 'Hindi - Mangal Font']]
    : [['english', 'English', 'QWERTY', 'English']];
  var KD_FONT = '';
  function hasFont(name) {
    try {
      var c = document.createElement('canvas').getContext('2d'), t = 'abcdefghijklmnopqrstuvwxyzABCDEF0123456789';
      c.font = '40px monospace'; var a = c.measureText(t).width;
      c.font = '40px "' + name + '", monospace'; return c.measureText(t).width !== a;
    } catch (e) { return false; }
  }
  function detectKD() {
    ['EHKruti', 'Kruti Dev 010', 'KrutiDev010', 'Kruti Dev 010 Regular', 'KRDV010'].some(function (n) { if (hasFont(n)) { KD_FONT = n; return true; } return false; });
  }
  if (document.fonts && document.fonts.load) document.fonts.load('20px EHKruti').then(detectKD, detectKD); else detectKD();
  function native() { return S.layout === 'english' || S.layout === 'external'; }
  function kdMode() { return S.layout === 'krutidev' && !!KD_FONT; }

  var S = {
    layout: LAYOUTS[0][0], minutes: exam.minutes,
    set: Object.assign({ tcs: true, bks: true, lbks: false, whl: true, hl: true, lc: true, as: true, xs: false, scr: true, snd: false, fs: 0 }, store.get('set2', {})),
    started: false, done: false, t0: 0, left: 0, timer: null,
    buf: '', keys: 0, bks: 0, words: [], text: '', passageId: '', title: ''
  };
  /* typing sound is off by default (speaker button turns it on); switch it off once for everyone who had the old default */
  if (!store.get('snd_v4', 0)) { S.set.snd = false; store.set('set2', S.set); store.set('snd_v4', 1); }

  var setup = $('#eh-setup'), test = $('#eh-test'), result = $('#eh-result');
  var pv = $('#eh-passage'), ta = $('#eh-input'), tm = $('#eh-timer');
  var pool = CFG.passages.filter(function (p) { return p.lang === (isHindi ? 'hi' : 'en'); });

  /* ---------- setup ---------- */
  (function fillSetup() {
    $('#eh-opt-layout').innerHTML = LAYOUTS.filter(function (l) { return l[0] !== 'external'; }).map(function (l) { return '<option value="' + l[0] + '">' + (l[0] === 'inscript' ? 'Hindi - Mangal Inscript' : l[1]) + '</option>'; }).join('');
    var last = (window.EH_TEST && window.EH_TEST.layout) || store.get('layout', '');
    if (last === 'external') last = 'inscript';
    if (LAYOUTS.some(function (l) { return l[0] === last; })) $('#eh-opt-layout').value = last;
    var ps = $('#eh-opt-passage');
    var pick = function () { var r = setup.querySelector('input[name="eh-psg"]:checked'); ps.value = r ? r.value : ''; };
    setup.querySelectorAll('input[name="eh-psg"]').forEach(function (r) { r.addEventListener('change', function () {
      pick(); var m = $('#eh-sp-modal'); if (m && r.closest('#eh-sp-modal')) m.hidden = true;
    }); });
    pick();
    if (CFG.fixedPassage) ps.value = CFG.fixedPassage;
    var mi = $('#eh-opt-min'); mi.value = String(exam.minutes); if (CFG.lockTime) mi.disabled = true;
    var un = $('#eh-opt-unit'); if (un) un.value = exam.unit === 'keys' ? 'keys' : 'words';
    /* UPSSSC and live tests show the full passage: no cut at the target, so speed is never capped by a short text */
    var li = $('#eh-opt-limit'); if (li && !li.value && +exam.target > 0 && exam.eval !== 'upsssc' && !CFG.live) li.value = exam.target;
    var nm = $('#eh-guest-name'); if (nm) nm.value = store.get('name', '');
    /* steps: 2 = passage select (first), 1 = instructions (then start) */
    var agree = $('#eh-agree'), next = $('#eh-next'), startBtn = $('#eh-start'), akey = 'agree_' + exam.slug;
    function psgTitle() {
      var id = CFG.fixedPassage || ps.value, t = 'Random Passage';
      pool.forEach(function (p, i) { if (p.id === id) t = 'Id- ' + (i + 1) + ' - ' + p.title; });
      return t;
    }
    function go(n) {
      $('#eh-step1').hidden = n !== 1; $('#eh-step2').hidden = n !== 2;
      setup.querySelectorAll('.eh-steps-nav li').forEach(function (li) { li.classList.toggle('on', li.getAttribute('data-go') === String(n)); });
      if (n === 1) { var im = $('#eh-im'); if (im) im.hidden = $('#eh-opt-layout').value !== 'inscript'; syncStart();
        $('#eh-ic-psg').textContent = psgTitle(); var g = $('#eh-guest-name'); if (g && g.value.trim()) $('#eh-ic-name').textContent = g.value.trim(); }
      window.scrollTo({ top: setup.getBoundingClientRect().top + window.scrollY - 90, behavior: 'smooth' });
    }
    function imExternal() { var r = setup.querySelector('input[name="eh-im"]:checked'); var im = $('#eh-im'); return !!(im && !im.hidden && r && r.value === 'external'); }
    function syncStart() {
      var chk = setup.querySelector('.eh-im-chk'); if (chk) chk.hidden = !imExternal();
      startBtn.disabled = !agree.checked || (imExternal() && !($('#eh-im-ok') || {}).checked);
    }
    S.imExternal = imExternal;
    agree.checked = !!store.get(akey, 0); syncStart();
    agree.addEventListener('change', function () { if (agree.checked) store.set(akey, 1); syncStart(); });
    setup.querySelectorAll('input[name="eh-im"], #eh-im-ok').forEach(function (r) { r.addEventListener('change', syncStart); });
    next.addEventListener('click', function () { go(1); });
    setup.querySelectorAll('[data-go]').forEach(function (b) { b.addEventListener('click', function () { go(+b.getAttribute('data-go')); }); });
    S.goStep = go;
    var so = $('#eh-sp-open'), sm = $('#eh-sp-modal');
    if (so && sm) {
      so.addEventListener('click', function () { sm.hidden = false; });
      sm.addEventListener('click', function (e) { if (e.target === sm || e.target.hasAttribute('data-x')) sm.hidden = true; });
    }
  })();

  function buildText(firstId) {
    var need = exam.unit === 'keys' ? Math.ceil(exam.target * 1.3) : Math.ceil(exam.target * 1.3 * 6.2);
    need = Math.max(need, S.minutes * 60 * (exam.eval === 'upsssc' || CFG.live ? 12 : 6));
    if (S.limit > 0) need = S.limitUnit === 'words' ? S.limit * 8 : S.limit + 10;
    var order = pool.slice();
    if (firstId) order.sort(function (a, b) { return (a.id === firstId ? -1 : 0) - (b.id === firstId ? -1 : 0); });
    else for (var i = order.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = order[i]; order[i] = order[j]; order[j] = t; }
    var parts = [], len = 0, k = 0;
    while (len < need && order.length && k < 40) { var p = order[k % order.length]; parts.push(p.text); len += p.chars + 1; k++; }
    S.passageId = order[0] ? order[0].id : ''; S.title = order[0] ? order[0].title : '';
    var txt = H.norm(parts.join(' '));
    /* Krutidev / Remington cannot type nukta letters (क़ ख़ ग़ ज़ फ़): use the plain letter, as the exam passages do */
    if (S.layout === 'krutidev' || S.layout === 'remington') {
      txt = txt.replace(/[\u0958-\u095B\u095E]/g, function (c) { return { '\u0958': '\u0915', '\u0959': '\u0916', '\u095A': '\u0917', '\u095B': '\u091C', '\u095E': '\u092B' }[c]; })
        .replace(/([\u0915\u0916\u0917\u091C\u092B])\u093C/g, '$1');
    }
    if (S.limit > 0) {
      if (S.limitUnit === 'words') txt = txt.split(/\s+/).slice(0, S.limit).join(' ');
      else if (txt.length > S.limit) { var cut = txt.lastIndexOf(' ', S.limit); txt = txt.slice(0, cut > 0 ? cut : S.limit); }
    }
    return txt;
  }

  /* ---------- settings ---------- */
  function applySettings() {
    var st = S.set;
    test.classList.toggle('tcs', !!st.tcs);
    var W = CFG.win || {}, kd = kdMode();
    var pbase = kd ? 23 : (+W.pfs || (isHindi ? 18 : 20)) + 1, tbase = kd ? 25 : (+W.tfs || 21) + 1; /* a little bigger than before */
    var plh = kd ? 26.5 : (+W.plh || pbase * 1.5), tlh = kd ? 33 : (+W.tlh || tbase * 1.3);
    var pf = pbase + st.fs, tf = tbase + st.fs;
    pv.style.fontSize = pf + 'px'; pv.style.lineHeight = (plh * pf / pbase).toFixed(2) + 'px';
    ta.style.fontSize = tf + 'px'; ta.style.lineHeight = (tlh * tf / tbase).toFixed(2) + 'px';
    $('#set-fs-v').textContent = Math.round(pf * 0.75);
    pv.style.visibility = st.scr ? '' : 'hidden';
    test.classList.toggle('np-show', !!st.scr); /* exams with no passage on screen (BSF, HCM): show it when 'Passage on Screen' is on */
    var pb = test.querySelector('[data-act="psg"]'); if (pb) pb.classList.toggle('on', !!st.scr);
    test.classList.toggle('snd-on', !!st.snd);
    if (S.words) mark(true);
    store.set('set2', st);
    var sb = $('#eh-snd-btn'); if (sb) sb.textContent = st.snd ? '❚❚ Stop Typing Sound' : '▷ Play Typing Sound';
    document.querySelectorAll('.eh-snd-lab').forEach(function (l) { l.textContent = st.snd ? 'Sound On' : 'Sound Off'; l.parentNode.classList.toggle('on', !!st.snd); });
    var fb = $('#eh-full'); if (fb) fb.textContent = document.fullscreenElement ? '⤢ Exit Fullscreen' : '⛶ Fullscreen';
  }
  [['set-tcs', 'tcs'], ['set-bks', 'bks'], ['set-lbks', 'lbks'], ['set-whl', 'whl'], ['set-hl', 'hl'], ['set-lc', 'lc'], ['set-as', 'as'], ['set-xs', 'xs'], ['set-scr', 'scr'], ['set-snd', 'snd']].forEach(function (p) {
    var el = $('#' + p[0]); el.checked = !!S.set[p[1]];
    el.addEventListener('change', function () { S.set[p[1]] = el.checked; applySettings(); });
  });
  $('#eh-snd-btn').textContent = S.set.snd ? '❚❚ Stop Typing Sound' : '▷ Play Typing Sound';
  $('#eh-snd-btn').addEventListener('click', function () { S.set.snd = !S.set.snd; $('#set-snd').checked = S.set.snd; applySettings(); });
  document.addEventListener('fullscreenchange', function () { applySettings(); });
  $('#eh-fs-plus').addEventListener('click', function () { S.set.fs = Math.min(8, S.set.fs + 1); applySettings(); });
  $('#eh-fs-minus').addEventListener('click', function () { S.set.fs = Math.max(-4, S.set.fs - 1); applySettings(); });
  var drawer = $('#eh-drawer');
  $('#eh-gear').addEventListener('click', function () { drawer.hidden = false; });
  drawer.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', function () { drawer.hidden = true; ta.focus(); }); });
  $('#eh-full').addEventListener('click', function () {
    if (!document.fullscreenElement) (test.requestFullscreen || test.webkitRequestFullscreen || function () {}).call(test);
    else document.exitFullscreen();
  });
  test.querySelectorAll('.ex-tool [data-act]').forEach(function (b) {
    b.addEventListener('click', function () {
      var a = b.getAttribute('data-act');
      if (a === 'mute') { S.set.snd = !S.set.snd; $('#set-snd').checked = S.set.snd; }
      if (a === 'psg') { S.set.scr = !S.set.scr; $('#set-scr').checked = S.set.scr; }
      else if (a === 'full') { $('#eh-full').click(); }
      else if (a === 'minus') S.set.fs = Math.max(-4, S.set.fs - 1);
      else if (a === 'plus') S.set.fs = Math.min(8, S.set.fs + 1);
      else if (a === 'reset') S.set.fs = 0;
      applySettings(); ta.focus();
    });
  });
  $('#eh-st-on').addEventListener('change', function () { $('#eh-stats').classList.toggle('off', !this.checked); });

  var actx = null;
  /* key click, like a real keyboard: a short burst of filtered noise plus a soft thud; space and backspace sound deeper */
  var nbuf = null, kLow = false;
  function click() {
    if (!S.set.snd) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      if (!nbuf) {
        nbuf = actx.createBuffer(1, Math.floor(actx.sampleRate * 0.05), actx.sampleRate);
        var d = nbuf.getChannelData(0);
        for (var i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 3);
      }
      /* mechanical keyboard: a sharp top click, a short plastic body and a low bottom-out thock */
      var t = actx.currentTime, out = actx.createGain(); out.gain.value = 0.9; out.connect(actx.destination);
      var hit = function (when, freq, q, gain, len, rate) {
        var s1 = actx.createBufferSource(), f1 = actx.createBiquadFilter(), g1 = actx.createGain();
        s1.buffer = nbuf; s1.playbackRate.value = rate; f1.type = 'bandpass'; f1.frequency.value = freq; f1.Q.value = q;
        g1.gain.setValueAtTime(0.0001, when); g1.gain.linearRampToValueAtTime(gain, when + 0.002); g1.gain.exponentialRampToValueAtTime(0.0001, when + len);
        s1.connect(f1); f1.connect(g1); g1.connect(out); s1.start(when); s1.stop(when + len + 0.01);
      };
      var r = 0.92 + Math.random() * 0.16;
      hit(t, (kLow ? 3200 : 4200) * r, 2.2, kLow ? 0.35 : 0.45, 0.012, 1.3);   /* click */
      hit(t + 0.004, (kLow ? 700 : 1100) * r, 1.4, kLow ? 0.7 : 0.55, kLow ? 0.06 : 0.04, 0.9); /* body */
      var o = actx.createOscillator(), g2 = actx.createGain();
      o.type = 'triangle'; o.frequency.setValueAtTime(kLow ? 140 : 210, t + 0.006); o.frequency.exponentialRampToValueAtTime(kLow ? 55 : 80, t + 0.04);
      g2.gain.setValueAtTime(0.0001, t + 0.006); g2.gain.linearRampToValueAtTime(kLow ? 0.32 : 0.2, t + 0.009); g2.gain.exponentialRampToValueAtTime(0.0001, t + (kLow ? 0.07 : 0.05));
      o.connect(g2); g2.connect(out); o.start(t + 0.006); o.stop(t + 0.08);
      hit(t + 0.055 + Math.random() * 0.02, 2600 * r, 1.8, 0.12, 0.015, 1.1); /* soft key release */
    } catch (e) {}
  }

  /* ---------- start ---------- */
  function startTest() {
    focusResult(false);
    /* open the exam window in full screen (like F11) as soon as the test starts; Esc or the Fullscreen button leaves it */
    try { if (!document.fullscreenElement) { var rf = test.requestFullscreen || test.webkitRequestFullscreen; if (rf) { var fp = rf.call(test); if (fp && fp.catch) fp.catch(function () {}); } } } catch (e) {}
    S.layout = $('#eh-opt-layout').value; store.set('layout', S.layout);
    if (S.layout === 'inscript' && S.imExternal && S.imExternal()) S.layout = 'external';
    var mi = $('#eh-opt-min'); if (!mi.disabled) S.minutes = Math.max(1, Math.min(60, parseInt(mi.value, 10) || exam.minutes));
    var nm = $('#eh-guest-name'); if (nm) store.set('name', nm.value.trim());
    var lim = $('#eh-opt-limit'); S.limit = lim ? Math.max(0, parseInt(lim.value, 10) || 0) : 0;
    S.limitUnit = $('#eh-opt-unit') ? $('#eh-opt-unit').value : 'keys';
    S.text = buildText(CFG.fixedPassage || $('#eh-opt-passage').value);
    S.words = S.text.split(/\s+/);
    S.show = kdMode() ? S.words.map(function (w) { return H.unicodeToKD(w); }) : S.words;
    S.left = S.minutes * 60; S.buf = ''; S.keys = 0; S.bks = 0; S.lock = 0; S.started = false; S.done = false; lastIdx = -1; wsDone = -1;

    var L = LAYOUTS.filter(function (l) { return l[0] === S.layout; })[0];
    $('#eh-layout-name').textContent = L[3];
    $('#eh-kb').textContent = L[2];
    var pidx = 1; pool.forEach(function (p, i) { if (p.id === S.passageId) pidx = i + 1; });
    $('#eh-ex-title').textContent = 'Typing Test Id ' + pidx + ' - ' + (S.title || exam.name);
    var nmv = CFG.userName || (nm && nm.value.trim()) || 'Candidate';
    $('#eh-cand-name').textContent = nmv.toUpperCase();
    $('#eh-cand-av').innerHTML = CFG.avatar ? '<img src="' + esc(CFG.avatar) + '" alt="">' : esc(nmv.charAt(0).toUpperCase());

    var kd = kdMode();
    pv.className = 'eh-passage' + (isHindi ? ' hi' : '') + (kd ? ' kd' : '');
    ta.className = 'eh-input' + (isHindi ? ' hi' : '') + (kd ? ' kd' : '');
    if (kd) { pv.style.fontFamily = ta.style.fontFamily = '"' + KD_FONT + '"'; } else { pv.style.fontFamily = ta.style.fontFamily = ''; }
    pv.innerHTML = S.show.map(function (w, i) { return '<span data-i="' + i + '">' + esc(w) + '</span>'; }).join(' ');
    pv.scrollTop = 0;
    ta.value = ''; ta.disabled = false;
    setup.hidden = true; result.hidden = true; test.hidden = false;
    document.documentElement.classList.add('eh-exam-on');
    applySettings(); drawTime(); stats(true);
    $('#st-kc').textContent = S.show.join(' ').length; $('#st-wc').textContent = S.words.length;
    setTimeout(function () { ta.focus(); }, 50);
    begin(); /* timer runs from the moment the window opens, like the exam */
  }

  function closeExam() {
    test.hidden = true; drawer.hidden = true;
    document.documentElement.classList.remove('eh-exam-on');
    if (document.fullscreenElement) document.exitFullscreen();
  }

  function drawTime() {
    var m = Math.floor(S.left / 60), s = S.left % 60;
    tm.textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
    tm.parentNode.classList.toggle('low', S.left <= 60);
  }

  function begin() {
    if (S.started) return;
    S.started = true; S.t0 = Date.now();
    S.timer = setInterval(function () {
      S.left = Math.max(0, S.minutes * 60 - Math.floor((Date.now() - S.t0) / 1000));
      drawTime();
      if (S.left <= 0) finish();
    }, 250);
  }

  function current() {
    if (S.layout === 'krutidev' || S.layout === 'remington') return H.kdToUnicode(S.buf);
    return S.layout === 'inscript' ? H.norm(S.buf) : ta.value;
  }
  function rawText() { return native() ? ta.value : S.buf; }

  /* ---------- highlight + scroll ---------- */
  var lastIdx = -1;
  function clearMark() { if (lastIdx >= 0) { var o = pv.querySelector('[data-i="' + lastIdx + '"]'); if (o) o.classList.remove('cur'); } }
  function curIndex() {
    var typed = current();
    var n = typed.trim() === '' ? 0 : typed.trim().split(/\s+/).length;
    if (typed.length && !/\s$/.test(typed)) n--;
    return Math.max(0, n);
  }
  var wsDone = -1;
  function wordStatus(n) {
    /* typed words before the current one: grey if same as passage, red if not (like the exam screen) */
    var typedW = current().trim() ? current().trim().split(/\s+/) : [];
    var from = Math.max(0, Math.min(n, wsDone) - 3), to = Math.max(n, wsDone + 1), i, el;
    for (i = from; i < to; i++) {
      el = pv.querySelector('[data-i="' + i + '"]'); if (!el) continue;
      el.classList.remove('wok', 'wbad');
      if (S.set.whl && !exam.nohl && i < n) el.classList.add(typedW[i] === S.words[i] ? 'wok' : 'wbad');
    }
    wsDone = n - 1;
  }
  function mark(force) {
    var n = curIndex();
    if (n === lastIdx && !force) return;
    clearMark();
    if (force) { pv.querySelectorAll('.wok,.wbad').forEach(function (e) { e.classList.remove('wok', 'wbad'); }); wsDone = S.words ? S.words.length : 0; }
    wordStatus(n);
    var b = pv.querySelector('[data-i="' + n + '"]');
    if (b && S.set.hl && !exam.nohl) b.classList.add('cur');
    if (b) {
      var top = b.offsetTop - pv.offsetTop;
      if (top > pv.scrollTop + pv.clientHeight - 50 || top < pv.scrollTop) pv.scrollTop = top - 30;
    }
    lastIdx = n;
  }

  /* ---------- live stats ---------- */
  var stT = 0;
  function lev(a, b) {
    if (a === b) return 0;
    var m = a.length, n = b.length; if (!m) return n; if (!n) return m;
    var p = new Array(n + 1), c = new Array(n + 1), i, j;
    for (j = 0; j <= n; j++) p[j] = j;
    for (i = 1; i <= m; i++) { c[0] = i; for (j = 1; j <= n; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); var t = p; p = c; c = t; }
    return p[n];
  }
  function errorsOf(ops) {
    var we = 0, ke = 0;
    ops.forEach(function (o) {
      if (o.t === 'ok') return;
      we++;
      if (o.t === 'om') ke += o.s.length; else if (o.t === 'add') ke += o.w.length; else ke += Math.max(1, lev(o.s, o.w));
    });
    return { we: we, ke: ke };
  }
  function stats(now) {
    var run = function () {
      var typed = current().trim(), tw = typed ? typed.split(/\s+/) : [];
      var done = /\s$/.test(current()) ? tw : tw.slice(0, -1);
      var e = errorsOf(compare(S.words, done));
      $('#st-kt').textContent = S.keys; $('#st-bk').textContent = S.bks;
      $('#st-ke').textContent = e.ke; $('#st-we').textContent = e.we;
      $('#st-tw').textContent = tw.length; $('#st-pw').textContent = Math.max(0, S.words.length - tw.length);
    };
    clearTimeout(stT);
    if (now) run(); else stT = setTimeout(run, 180);
  }

  function render() { ta.value = kdMode() ? S.buf : current(); ta.scrollTop = ta.scrollHeight; ta.setSelectionRange(ta.value.length, ta.value.length); }
  /* UPSSSC rule: Backspace works only on the word being typed and the one before it; older words are locked */
  function updLock() {
    if (exam.eval !== 'upsssc') return;
    var m = /^([\s\S]*\s)?\S+\s+\S*$/.exec(rawText()), l = m ? (m[1] || '').length : 0;
    if (l > S.lock) S.lock = l;
  }
  function after() { updLock(); mark(); stats(); }

  /* ---------- keyboard ---------- */
  function onKey(e) {
    if (S.done) return;
    kLow = e.key === ' ' || e.code === 'Space' || e.key === 'Backspace';
    /* Alt codes (hold Alt, type 0197 on the number pad, let go): Krutidev ऊ and other signs are typed this way */
    if (e.altKey && !e.ctrlKey && !native()) {
      var dg = /^(Numpad|Digit)([0-9])$/.exec(e.code);
      if (dg) { e.preventDefault(); S.alt = (S.alt || '') + dg[2]; return; }
    }
    if (e.ctrlKey || e.metaKey || e.altKey) { if (/^(KeyV|KeyA|KeyZ|KeyY|KeyX)$/.test(e.code)) e.preventDefault(); return; }
    var raw = rawText();
    if (e.key === 'Backspace') {
      if (!S.set.bks || !raw.length) { e.preventDefault(); return; }
      if (S.set.lbks && /\s$/.test(raw)) { e.preventDefault(); return; }
      if (exam.eval === 'upsssc' && raw.length <= (S.lock || 0)) { e.preventDefault(); return; }
      S.bks++; click();
      if (!native()) { e.preventDefault(); S.buf = Array.from(S.buf).slice(0, -1).join(''); render(); }
      setTimeout(after, 0);
      return;
    }
    if (/^(ArrowLeft|ArrowRight|ArrowUp|ArrowDown|Home|End|PageUp|PageDown|Delete|Tab|Enter|Clear|Insert)$/.test(e.key) && !(/^Numpad[0-9]$/.test(e.code) && !native())) { e.preventDefault(); return; }
    if (e.key === ' ' || e.code === 'Space') {
      if (!raw.length || (!S.set.xs && /\s$/.test(raw))) { e.preventDefault(); return; }
      /* like the real exam: after the passage's word count, space bar stops adding words */
      if (raw.trim().split(/\s+/).length >= S.words.length) { e.preventDefault(); return; }
    }
    if (native()) {
      if (e.key.length === 1) { begin(); S.keys++; click(); setTimeout(after, 0); }
      return;
    }
    var map = S.layout === 'inscript' ? H.INSCRIPT : H.US;
    var pair = map[e.code];
    /* number pad keys (and any digit key the map lacks) type the plain digit, as in the real exam */
    var np = /^Numpad([0-9])$/.exec(e.code);
    if (np) pair = [np[1], np[1]]; /* number pad digits, even with Num Lock off */
    else if (!pair && /^Numpad/.test(e.code) && /^[.+\-*\/]$/.test(e.key)) pair = [e.key, e.key];
    else if (!pair && /^[0-9]$/.test(e.key)) pair = [e.key, e.key];
    if (!pair) { if (e.key.length === 1) e.preventDefault(); return; }
    e.preventDefault();
    begin(); S.keys++; click();
    S.buf += pair[e.shiftKey ? 1 : 0];
    render(); after();
  }

  /* ---------- evaluation ---------- */
  var compare = window.EHEval.compare;

  function finish() {
    if (S.done) return;
    S.done = true; clearInterval(S.timer); ta.disabled = true;
    var secs = S.started ? Math.min(S.minutes * 60, (Date.now() - S.t0) / 1000) : 0;
    var mins = Math.max(secs / 60, 1 / 60);
    var typed = H.norm(current()).trim();
    var tw = typed ? typed.split(/\s+/) : [];
    var ops = compare(S.words, tw);
    var full = 0, half = 0;
    ops.forEach(function (o) { if (o.t === 'half') half++; else if (o.t !== 'ok') full++; });
    var e = errorsOf(ops);
    var words = tw.length, errs = full + half / 2;
    var errPct = words ? Math.min(100, (errs / words) * 100) : 100;
    var gross = Math.round(words / mins), net = Math.max(0, Math.round((words - errs) / mins));
    var acc = words ? Math.max(0, 100 - errPct) : 0;
    /* key depressions = what is left on screen at the end; deleted letters and extra presses are not counted */
    var tl = Array.from(rawText().replace(/\s+$/, '')).length;
    /* phone keyboards do not report key presses, so when the count is 0 use the letters typed */
    var kd = tl; /* letters on screen; Hindi IME keyboards and phones do not report every key press, so the press count is not used */
    /* a typed word earns at most its passage word's length + 2 letters, so a long run of keys without spaces cannot inflate the speed */
    var cl = function (x) { return Array.from(x || '').length; }, kc = 0, nt = 0;
    ops.forEach(function (o) { if (o.w == null) return; nt += String(o.w).split(' ').length; kc += Math.min(cl(o.w), o.s != null ? cl(o.s) + 2 : 12); });
    if (nt) kd = Math.min(tl, kc + nt - 1);
    var amount = exam.unit === 'keys' ? kd : words;
    /* speed is worked out over the length the person chose for this test (practice may be shorter or longer than the exam) */
    var XD = {}; for (var xk in exam) XD[xk] = exam[xk]; XD.minutes = S.minutes || exam.minutes;
    var V = window.EHEval.verdict({ keys: kd, words: words, full: full, half: half, err: errPct, minutes: secs / 60 }, XD), pass = V.pass;
    if (V.rule === 'upsssc') { net = Math.floor(V.wpm); gross = Math.round(V.words / V.mins); }
    if (V.rule === 'uppolice') { net = +V.wpm.toFixed(2); gross = Math.round(V.words / V.mins); }
    var R = {
      exam: exam.slug, layout: S.layout, passage: S.passageId, minutes: +(secs / 60).toFixed(2), dur: XD.minutes,
      keys: kd, chars: typed.length, words: words, full: full, half: half, backspaces: S.bks, kerr: e.ke,
      gross: gross, net: net, acc: +acc.toFixed(2), err: +errPct.toFixed(2), pass: pass ? 1 : 0, live: CFG.live || ''
    };
    closeExam();
    if (CFG.full === 1) {
      /* Full Exam part 1: no result screen; Hindi follows after a short break */
      try { sessionStorage.setItem('eh_full_en', JSON.stringify({ net: R.net, gross: R.gross, acc: R.acc, err: R.err, pass: R.pass, words: R.words, keys: R.keys, full: full, half: half, set: CFG.fullSet, t: Date.now() })); } catch (x) {}
      R.mist = window.EHEval.mistakes(ops); R.title = S.title;
      var su = 0; ops.forEach(function (o) { if (o.t !== 'add') su += o.s.split(' ').length; });
      R.typed = typed.slice(0, 12000); R.src = S.words.slice(0, su + 15).join(' ').slice(0, 14000);
      var sp = save(R, true); fullBreak(R, sp);
      return;
    }
    showResult(R, ops);
    var srcUpto = 0; ops.forEach(function (o) { if (o.t !== 'add') srcUpto += o.s.split(' ').length; });
    R.typed = typed.slice(0, 20000); R.src = S.words.slice(0, srcUpto + 15).join(' ').slice(0, 25000);
    R.mist = window.EHEval.mistakes(ops); R.title = S.title;
    save(R);
  }

  /* result like AR: only the dashboard on screen (site header, page heading, side boxes hidden) */
  function focusResult(on) {
    [].forEach.call(document.querySelectorAll('.eh-rhide'), function (x) { x.classList.remove('eh-rhide'); });
    if (!on) return;
    for (var el = result; el && el.parentNode && el !== document.body; el = el.parentNode) {
      [].forEach.call(el.parentNode.children, function (c) { if (c !== el && !/^(SCRIPT|STYLE|LINK)$/.test(c.tagName)) c.classList.add('eh-rhide'); });
    }
  }
  function nextRadio() {
    var rs = [].slice.call(document.querySelectorAll('input[name=eh-psg]')), cur = S.passageId || ((document.querySelector('input[name=eh-psg]:checked') || {}).value);
    for (var i = 0; i < rs.length; i++) if (rs[i].value === cur) return rs[i + 1] || null;
    return null;
  }
  function showResult(R, ops) {
    result.hidden = false; setup.hidden = true; focusResult(true);
    var nb = $('#eh-next-auto'); if (nb) nb.hidden = !!document.getElementById('eh-next-psg') || !nextRadio();
    document.body.classList.add('eh-has-result'); /* dashboard first: page header and side ranking move out of the way */
    R.pending = Math.max(0, S.words.length - R.words); R.total = S.words.join(' ').length; R.dur = R.dur || exam.minutes; var XD = {}; for (var xk in exam) XD[xk] = exam[xk]; XD.minutes = R.dur;
    R.title = S.title; R.date = new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    $('#eh-res-dash').innerHTML = window.EHEval.dashboard(R, XD, ops);
    window.EHEval.bindDash($('#eh-res-dash'));
    if (CFG.full === 2) fullSummary(R);
    $('#eh-res-link').hidden = true;
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  function save(R, keep) {
    if (!CFG.loggedIn) R.name = store.get('name', '');
    return fetch(CFG.rest + 'result', { method: 'POST', credentials: 'same-origin', keepalive: !!keep, headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CFG.nonce }, body: JSON.stringify(R) })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        var s = $('#eh-res-saved'); if (s) s.textContent = j && j.ok ? (j.rank ? 'Result saved · your rank today #' + j.rank : 'Result saved') : '';
        if (j && j.url) { var l = $('#eh-res-link'); l.href = j.url; l.hidden = false; }
        document.dispatchEvent(new Event('eh:saved'));
      })
      .catch(function () {});
  }

  /* ---------- 3284 Full Exam: English, then Hindi ---------- */
  function fullBreak(R, sp) {
    var left = 15, go = false, ov = document.createElement('div');
    ov.className = 'eh-full-break';
    ov.innerHTML = '<div class="eh-fb-box"><span class="eh-fb-tag">UPSSSC 3284 Full Exam</span><h2>English submit हो गया ✓</h2>' +
      '<p>English · <b>' + R.net + ' WPM</b> · Accuracy ' + R.acc + '% · ' + (R.pass ? '<b class="ok">Qualified</b>' : '<b class="no">Not qualified</b>') + '</p>' +
      '<p class="eh-fb-next">हिंदी (' + (CFG.fullKb === 'inscript' ? 'Mangal Inscript' : 'Krutidev') + ') <b id="eh-fb-n">15</b> सेकंड में अपने आप शुरू होगी</p>' +
      '<button type="button" class="btn dark" id="eh-fb-go">हिंदी अभी शुरू करें →</button></div>';
    document.body.appendChild(ov);
    function next() {
      if (go) return; go = true; $('#eh-fb-go').textContent = 'Hindi खुल रही है…';
      var t = new Promise(function (r) { setTimeout(r, 2500); });
      Promise.race([sp || t, t]).then(function () { location.href = CFG.fullNext; }, function () { location.href = CFG.fullNext; });
    }
    $('#eh-fb-go').addEventListener('click', next);
    var iv = setInterval(function () { left--; var n = $('#eh-fb-n'); if (n) n.textContent = Math.max(0, left); if (left <= 0) { clearInterval(iv); next(); } }, 1000);
  }
  function fullSummary(H2) {
    var E = null; try { E = JSON.parse(sessionStorage.getItem('eh_full_en') || 'null'); } catch (x) {}
    var box = document.createElement('div'); box.className = 'eh-full-sum';
    var row = function (n, r) { return '<div class="eh-fs-c"><span>' + n + '</span>' + (r ? '<b>' + r.net + ' WPM</b><em>Accuracy ' + r.acc + '% · ' + (r.pass ? '<i class="ok">Qualified</i>' : '<i class="no">Not qualified</i>') + '</em>' : '<b>—</b><em>English भाग नहीं मिला</em>') + '</div>'; };
    var both = E && E.pass && H2.pass;
    box.innerHTML = '<h3>UPSSSC 3284 Full Exam · Set ' + (CFG.fullSet || 1) + ' का परिणाम</h3><div class="eh-fs-g">' + row('भाग 1 · English', E) + row('भाग 2 · हिंदी', H2) +
      '<div class="eh-fs-c ' + (both ? 'pass' : 'fail') + '"><span>कुल परिणाम</span><b>' + (both ? 'Qualified ✓' : 'Not qualified') + '</b><em>दोनों भाषाओं में Qualified होना ज़रूरी</em></div></div>';
    var ns = (CFG.fullSet || 1) + 1; if (ns > (CFG.fullCount || 1)) ns = 1;
    box.innerHTML += '<a class="eh-ft-go" style="display:inline-block;margin-top:12px;text-decoration:none" href="' + CFG.fullFirst + '?full=1&fs=' + ns + '&kb=' + (CFG.fullKb || 'krutidev') + '">अगला Set ' + ns + ' शुरू करें →</a>';
    var d = $('#eh-res-dash'); d.insertBefore(box, d.firstChild);
    try { sessionStorage.removeItem('eh_full_en'); } catch (x) {}
  }
  if (CFG.full === 2) {
    /* Hindi part opens straight into the exam window, after the Krutidev font is ready */
    var fgo = function () { setTimeout(function () { if (!S.started) startTest(); }, 400); };
    if (document.fonts && document.fonts.load) document.fonts.load('20px EHKruti').then(fgo, fgo); else fgo();
  }

  /* ---------- buttons ---------- */
  function twoStep(btn, label, fn) {
    btn.addEventListener('click', function () {
      if (btn.dataset.arm === '1') { btn.dataset.arm = ''; btn.textContent = label; fn(); return; }
      btn.dataset.arm = '1'; btn.textContent = 'Sure? Press again';
      setTimeout(function () { btn.dataset.arm = ''; btn.textContent = label; }, 3000);
    });
  }
  $('#eh-start').addEventListener('click', startTest);
  twoStep($('#eh-submit'), 'Submit', finish);
  (function () {
    var cb = $('#eh-cancel'), doCancel = function () { S.done = true; clearInterval(S.timer); closeExam(); setup.hidden = false; };
    cb.addEventListener('click', function () {
      if (!S.set.lc) { doCancel(); return; }
      if (cb.dataset.arm === '1') { cb.dataset.arm = ''; cb.textContent = 'Cancel'; doCancel(); return; }
      cb.dataset.arm = '1'; cb.textContent = 'Sure? Press again';
      setTimeout(function () { cb.dataset.arm = ''; cb.textContent = 'Cancel'; }, 3000);
    });
  })();
  $('#eh-retype').addEventListener('click', function () { if (S.passageId) $('#eh-opt-passage').value = S.passageId; result.hidden = true; startTest(); });
  (function () {
    var q = new URLSearchParams(location.search), rp = q.get('passage');
    if (rp && !CFG.fixedPassage) {
      var r = setup.querySelector('input[name="eh-psg"][value="' + rp.replace(/[^a-z0-9]/gi, '') + '"]');
      if (r) { r.checked = true; r.dispatchEvent(new Event('change')); }
      else $('#eh-opt-passage').value = rp.replace(/[^a-z0-9]/gi, '');
      var lim = q.get('limit'); if (lim && $('#eh-opt-limit')) $('#eh-opt-limit').value = parseInt(lim, 10) || '';
      S.goStep(1);
    }
  })();
  if ($('#eh-next-auto')) $('#eh-next-auto').addEventListener('click', function () {
    var n = nextRadio(); if (!n) return;
    n.checked = true; n.dispatchEvent(new Event('change', { bubbles: true }));
    if ($('#eh-opt-passage')) $('#eh-opt-passage').value = n.value;
    document.body.classList.remove('eh-has-result'); result.hidden = true; startTest();
  });
  $('#eh-again').addEventListener('click', function () { focusResult(false); document.body.classList.remove('eh-has-result'); result.hidden = true; setup.hidden = false; if (S.goStep) S.goStep(2); });
  ta.addEventListener('keydown', onKey);
  ta.addEventListener('paste', function (e) { e.preventDefault(); });
  ta.addEventListener('drop', function (e) { e.preventDefault(); });
  ta.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  ta.addEventListener('input', function () { if (!native()) render(); else after(); });
  /* finish an Alt code when Alt is let go (Windows cp1252 numbers, as in every typing software) */
  var CP = {128:8364,130:8218,131:402,132:8222,133:8230,134:8224,135:8225,136:710,137:8240,138:352,139:8249,140:338,142:381,145:8216,146:8217,147:8220,148:8221,149:8226,150:8211,151:8212,152:732,153:8482,154:353,155:8250,156:339,158:382,159:376};
  ta.addEventListener('keyup', function (e) {
    if ((e.key !== 'Alt' && e.key !== 'AltGraph') || !S.alt) return;
    e.preventDefault(); var n = parseInt(S.alt, 10); S.alt = '';
    if (S.done || native() || !(n > 31 && n < 256)) return;
    var ch = String.fromCharCode(CP[n] || n);
    begin(); S.keys++; click(); S.buf += ch; render(); after();
  });
  /* the browser may also insert the Alt-code letter itself; the buffer already has it */
  ta.addEventListener('beforeinput', function (e) {
    if (native() || e.inputType !== 'insertText') return;
    e.preventDefault();
    /* Alt code letter sent by Windows itself (e.g. Alt+0161 = ¡ = ँ): take it, so the code still works if Alt's keyup never arrives */
    if (S.alt && e.data && e.data.length === 1 && !S.done) { S.alt = ''; begin(); S.keys++; click(); S.buf += e.data; render(); after(); }
  });
  ta.addEventListener('mousedown', function (e) { if (!native()) { e.preventDefault(); ta.focus(); } });
  pv.addEventListener('copy', function (e) { e.preventDefault(); });
  window.addEventListener('beforeunload', function (e) { if (S.started && !S.done) { e.preventDefault(); e.returnValue = ''; } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !drawer.hidden) drawer.hidden = true; });
})();
