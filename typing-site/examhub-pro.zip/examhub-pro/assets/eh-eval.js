/* Exam Hub — typing evaluation (shared by test window and saved result page) */
(function () {
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  function stripP(w) { return w.replace(/[.,;:!?'"‘’“”()\-।|/]/g, ''); }
  function lev(a, b) {
    if (a === b) return 0;
    var la = a.length, lb = b.length, prev = [], cur, i, j;
    for (j = 0; j <= lb; j++) prev[j] = j;
    for (i = 1; i <= la; i++) {
      cur = [i];
      for (j = 1; j <= lb; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[lb];
  }
  /* costs (x2): same 0 · case/punct 2 · close spelling 4 · different 6 · missing/extra word 4 · joined/split word 2 */
  function compare(src, typ) {
    var m = typ.length;
    var n = Math.min(src.length, m + Math.max(60, Math.ceil(m * 0.5))); /* room for skipped lines */
    var W = m + 1, D = new Uint32Array((n + 1) * W), i, j;
    var cost = function (x, y) {
      if (x === y) return 0;
      if (x.toLowerCase() === y.toLowerCase() || (stripP(x) && stripP(x) === stripP(y))) return 2;
      var mx = Math.max(x.length, y.length);
      return lev(x, y) <= Math.max(1, Math.floor(mx / 3)) ? 4 : 6;
    };
    for (i = 0; i <= n; i++) D[i * W] = i * 4;
    for (j = 0; j <= m; j++) D[j] = j * 4;
    for (i = 1; i <= n; i++) for (j = 1; j <= m; j++) {
      var v = D[(i - 1) * W + j - 1] + cost(src[i - 1], typ[j - 1]);
      var b2 = D[(i - 1) * W + j] + 4; if (b2 < v) v = b2;
      var d2 = D[i * W + j - 1] + 4; if (d2 < v) v = d2;
      if (i > 1 && typ[j - 1] === src[i - 2] + src[i - 1]) { var g = D[(i - 2) * W + j - 1] + 2; if (g < v) v = g; }
      if (j > 1 && typ[j - 2] + typ[j - 1] === src[i - 1]) { var h = D[(i - 1) * W + j - 2] + 2; if (h < v) v = h; }
      D[i * W + j] = v;
    }
    var best = 0;
    for (i = 0; i <= n; i++) if (D[i * W + m] <= D[best * W + m]) best = i;
    var ops = []; i = best; j = m;
    while (i > 0 || j > 0) {
      var here = D[i * W + j];
      if (i > 0 && j > 0 && here === D[(i - 1) * W + j - 1] + cost(src[i - 1], typ[j - 1])) { ops.push({ t: src[i - 1] === typ[j - 1] ? 'ok' : 'sub', s: src[i - 1], w: typ[j - 1] }); i--; j--; }
      else if (i > 1 && j > 0 && typ[j - 1] === src[i - 2] + src[i - 1] && here === D[(i - 2) * W + j - 1] + 2) { ops.push({ t: 'half', s: src[i - 2] + ' ' + src[i - 1], w: typ[j - 1], why: 'space' }); i -= 2; j--; }
      else if (j > 1 && i > 0 && typ[j - 2] + typ[j - 1] === src[i - 1] && here === D[(i - 1) * W + j - 2] + 2) { ops.push({ t: 'half', s: src[i - 1], w: typ[j - 2] + ' ' + typ[j - 1], why: 'space' }); i--; j -= 2; }
      else if (i > 0 && here === D[(i - 1) * W + j] + 4) { ops.push({ t: 'om', s: src[i - 1] }); i--; }
      else { ops.push({ t: 'add', w: typ[j - 1] }); j--; }
    }
    ops.reverse();
    var out = [];
    for (var k = 0; k < ops.length; k++) {
      var o = ops[k], nx = ops[k + 1];
      if (o.t === 'om' && nx && nx.t === 'sub' && nx.w === o.s + nx.s) { out.push({ t: 'half', s: o.s + ' ' + nx.s, w: nx.w, why: 'space' }); k++; continue; }
      if (o.t === 'sub' && nx && nx.t === 'om' && o.w === o.s + nx.s) { out.push({ t: 'half', s: o.s + ' ' + nx.s, w: o.w, why: 'space' }); k++; continue; }
      if (o.t === 'sub' && nx && nx.t === 'add' && o.w + nx.w === o.s) { out.push({ t: 'half', s: o.s, w: o.w + ' ' + nx.w, why: 'space' }); k++; continue; }
      if (o.t === 'add' && nx && nx.t === 'sub' && o.w + nx.w === nx.s) { out.push({ t: 'half', s: nx.s, w: o.w + ' ' + nx.w, why: 'space' }); k++; continue; }
      /* transposition: two neighbouring words typed in the reverse order count as one half mistake */
      if (o.t === 'sub' && nx && nx.t === 'sub' && o.s === nx.w && o.w === nx.s) { out.push({ t: 'half', s: o.s + ' ' + nx.s, w: o.w + ' ' + nx.w, why: 'trans' }); k++; continue; }
      var n2x = ops[k + 2];
      if (o.t === 'om' && nx && nx.t === 'ok' && n2x && n2x.t === 'add' && n2x.w === o.s) { out.push({ t: 'half', s: o.s + ' ' + nx.s, w: nx.s + ' ' + n2x.w, why: 'trans' }); k += 2; continue; }
      if (o.t === 'add' && nx && nx.t === 'ok' && n2x && n2x.t === 'om' && n2x.s === o.w) { out.push({ t: 'half', s: nx.s + ' ' + n2x.s, w: o.w + ' ' + nx.s, why: 'trans' }); k += 2; continue; }
      if (o.t === 'sub') {
        if (o.s.toLowerCase() === o.w.toLowerCase()) { out.push({ t: 'half', s: o.s, w: o.w, why: 'case' }); continue; }
        if (stripP(o.s) && stripP(o.s) === stripP(o.w)) { out.push({ t: 'half', s: o.s, w: o.w, why: 'punct' }); continue; }
      }
      out.push(o);
    }
    out.rest = src.slice(best); /* part of the passage not reached (time over) - shown, never counted */
    return out;
  }


  var WHY = { space: 'Spacing error', case: 'Capital/small letter error', punct: 'Punctuation error', trans: 'Words in the wrong order' };
  function inline(ops) {
    return ops.map(function (o) {
      if (o.t === 'ok') return '<span class="d-ok">' + esc(o.s) + '</span>';
      if (o.t === 'om') return '<span class="d-om" title="Missed word">' + esc(o.s) + '</span>';
      if (o.t === 'add') return '<span class="d-add" title="Added words">' + esc(o.w) + '</span>';
      if (o.t === 'half') return '<span class="d-half" title="Half mistake: ' + (WHY[o.why] || '') + '">' + esc(o.w) + ' <s>' + esc(o.s) + '</s></span>';
      return '<span class="d-sub" title="Full mistake">' + esc(o.w) + ' <s>' + esc(o.s) + '</s></span>';
    }).join(' ') + restHtml(ops);
  }
  /* the part of the passage that was not reached, in grey (max 200 words) */
  function restHtml(ops) {
    var r = ops.rest || []; if (!r.length) return '';
    var shown = r.slice(0, 200).map(esc).join(' ');
    return '<div class="d-rest"><b class="d-rest-h">Not typed (time over) · ' + r.length + ' words</b> ' + shown + (r.length > 200 ? ' …' : '') + '</div>';
  }
  function twoCol(ops) {
    var L = [], R = [], run = 0;
    function flush() { if (run) { R.push('<span class="d-skip">⟵ ' + run + ' word' + (run > 1 ? 's' : '') + ' missed</span>'); run = 0; } }
    ops.forEach(function (o, k) {
      var cls = o.t === 'ok' ? 'd-ok' : o.t === 'half' ? 'd-half' : o.t === 'om' ? 'd-om' : o.t === 'add' ? 'd-add' : 'd-sub';
      if (o.t === 'om') {
        /* a run of 3+ missed words is a skipped line: mark it as one block */
        var a = k, b = k; while (a > 0 && ops[a - 1].t === 'om') a--; while (b < ops.length - 1 && ops[b + 1].t === 'om') b++;
        var long = b - a + 1 >= 3;
        L.push((long && k === a ? '<span class="d-skipblk" title="Skipped: ' + (b - a + 1) + ' words">' : '') + '<span class="' + cls + '">' + esc(o.s) + '</span>' + (long && k === b ? '</span>' : ''));
        run++; return;
      }
      flush();
      L.push('<span class="' + cls + '">' + esc(o.s) + '</span>');
      R.push('<span class="' + cls + '">' + esc(o.w) + '</span>');
    });
    flush();
    return '<div class="eh-cmp"><div><h4>Original Passage</h4><div class="eh-cmp-t">' + L.join(' ') + restHtml(ops) + '</div></div><div><h4>What you typed</h4><div class="eh-cmp-t">' + R.join(' ') + '</div></div></div>';
  }
  function counts(ops) {
    var c = { full: 0, half: 0, om: 0, add: 0, sub: 0, space: 0, case: 0, punct: 0, trans: 0 };
    ops.forEach(function (o) {
      if (o.t === 'half') { c.half++; c[o.why] = (c[o.why] || 0) + 1; }
      else if (o.t !== 'ok') { c.full++; c[o.t]++; }
    });
    return c;
  }
  function mistakes(ops) {
    var m = [];
    ops.forEach(function (o) { if ((o.t === 'sub' || o.t === 'half') && m.length < 60) m.push([o.w, o.s]); });
    return m;
  }

  function fmtMin(m) { var s = Math.round(m * 60); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2) + ' min'; }
  /* Pass or fail, by the exam's own rule.
     UPSSSC (X.eval === 'upsssc'): words = key depressions ÷ 5 (R.mode 'words' = real words typed, shown only as a second view); mistakes = full + half ÷ 2; the first 5 mistakes are free,
     each mistake after that cuts 6 words (the wrong word + 5 words), matching AR Typing; speed = net words ÷ minutes; needs X.wpm.
     Others: key depressions (or words) must reach the target and error % must stay within the limit. */
  function verdict(R, X) {
    var allowed = X.allowed || 5;
    if (X.eval === 'upsssc' && X.wpm) {
      var errs = (+R.full || 0) + (+R.half || 0) / 2, byW = R.mode === 'words' || !(+R.keys), kw = byW ? (+R.words || 0) : (+R.keys) / 5, pen = Math.max(0, errs - 5) * 6, nw = Math.max(0, kw - pen);
      var m = Math.max(+R.minutes || 0, +X.minutes || 5), sp = nw / m;
      return { rule: 'upsssc', pass: sp >= X.wpm, wpm: sp, words: kw, errs: errs, pen: pen, netWords: nw, mins: m, need: +X.wpm, byWords: byW };
    }
    var amount = X.unit === 'keys' ? R.keys : R.words;
    return { rule: 'std', pass: amount >= X.target && R.err <= allowed, amount: amount };
  }
  function n2(v) { return (Math.round(v * 100) / 100).toString(); }
  /* R: net gross acc err keys kerr words full half backspaces minutes pass pending title date ; X: exam */
  function dashboard(R, X, ops) {
    if (!(X.eval === 'upsssc' && X.wpm)) return dashBody(R, X, ops);
    /* official result = key stroke formula (5 key strokes = 1 word). The switch only shows the word-count view. */
    var W = {}; for (var k in R) W[k] = R[k]; W.mode = 'words';
    return '<div class="eh-kv" data-k="keys">' + dashBody(R, X, ops) + '</div><div class="eh-kv" data-k="words" hidden><p class="eh-ksw-note">Word-count view (only for comparison). Your result and rank use the key stroke formula.</p>' + dashBody(W, X, ops) + '</div>';
  }
  function eh_tgt(X, t) { return X.wpm ? X.wpm + '' : t; }
  function dashBody(R, X, ops) {
    var V = verdict(R, X), up = V.rule === 'upsssc'; R.pass = V.pass ? 1 : 0;
    var c = counts(ops), allowed = X.allowed || 5, keysMode = X.unit === 'keys';
    var tgt = (+X.target).toLocaleString('en-IN') + (keysMode ? ' key depressions' : ' words');
    var errs = R.full + R.half / 2, mins = Math.max(R.minutes, 1 / 60);
    var head = '<div class="eh-dash-head"><div><p class="eh-kicker">Performance Dashboard</p><h2>' + esc(X.name) + '</h2>' +
      '<p class="muted">' + (R.title ? 'Passage: <b>' + esc(R.title) + '</b> · ' : '') + (R.date ? esc(R.date) + ' · ' : '') + (up ? 'Needed ' + V.need + ' WPM in ' + X.minutes + ' min · first 5 mistakes free, then 6 words cut for each extra mistake' : 'Target ' + tgt + ' in ' + X.minutes + ' min · Allowed error ' + allowed + '%') + '</p></div>' +
      '<div class="eh-verdict ' + (R.pass ? 'ok' : 'no') + '">' + (R.pass ? '✔ Qualified' : '✘ Not Qualified') + '</div></div>';
    var mm = function (m) { m = Math.round((+m || 0) * 60); return ('0' + Math.floor(m / 60)).slice(-2) + ':' + ('0' + m % 60).slice(-2) + ' min.'; };
    var info = '<div class="eh-dash-info">' + [['Exam Title', esc(X.name)], ['Passage Title', esc(R.title || '—')], ['Key Depression', R.total ? R.total : '—'], ['Time Duration', mm(R.dur || X.minutes)], ['Typing Date', esc(R.date || '—')], ['Time Taken', mm(R.minutes)]]
      .map(function (k) { return '<div><span>' + k[0] + ':</span> <b>' + k[1] + '</b></div>'; }).join('') + '</div>';
    var ICO = ['<path d="M12 14l4-4"/><path d="M3.3 16a9 9 0 1 1 17.4 0"/>','<path d="M3 12h4l3-8 4 16 3-8h4"/>','<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>','<circle cx="12" cy="12" r="9"/><path d="M15 9l-6 6M9 9l6 6"/>','<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>','<path d="M12 3l9 16H3z"/><path d="M12 10v4M12 17h.01"/>','<circle cx="12" cy="12" r="9"/><path d="M12 3v18" /><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor" stroke="none" opacity=".35"/>','<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'];
    var cards = [
      ['Gross Speed', up ? n2(V.words / V.mins) : R.gross, 'WPM', 'c2'], ['Accuracy', R.acc, '%', 'c3'], up ? ['Mistakes', n2(V.errs), '/ 5 free', V.errs > 5 ? 'bad' : 'c4'] : ['Error', R.err, '%', R.err > allowed ? 'bad' : 'c4'],
      up ? ['Total Keystrokes / Words Typed', R.keys + ' / ' + n2(V.words), '', 'c5'] : ['Key Depressions', R.keys, keysMode ? '/ ' + X.target : '', keysMode && R.keys < X.target ? 'bad' : 'c5'], ['Full Mistakes', R.full, '', 'c6'], ['Half Mistakes', R.half, '', 'c7'], ['Time Taken', fmtMin(R.minutes), '', 'c8']
    ];
    /* key strokes card comes first, as on the exam's own result sheet */
    cards.unshift(cards.splice(3, 1)[0]);
    var ICO2 = [ICO[4], ICO[1], ICO[2], ICO[3], ICO[5], ICO[6], ICO[7]];
    var wide = cards.shift(), wideIc = ICO2.shift();
    wide = '<div class="eh-dcard eh-wide"><div><span>' + wide[0] + '</span><b>' + wide[1] + ' <small>' + wide[2] + '</small></b></div><i class="eh-dc-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + wideIc + '</svg></i></div>';
    cards = cards.map(function (k, i) { var ICO = ICO2; return '<div class="eh-dcard ' + k[3] + '"><div class="eh-dc-top"><span>' + k[0] + '</span><i class="eh-dc-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + ICO[i] + '</svg></i></div><b>' + k[1] + ' <small>' + k[2] + '</small></b></div>'; }).join('');
    var mini = [['Words Typed', R.words], ['Keystroke Errors', R.kerr], ['Backspace', R.backspaces], ['Missed words', c.om], ['Added words', c.add], ['Wrong words', c.sub], ['Space/Case/Punct/Order', c.space + '/' + c.case + '/' + c.punct + '/' + c.trans], ['Pending Words', R.pending || 0]]
      .map(function (k) { return '<div><span>' + k[0] + '</span><b>' + k[1] + '</b></div>'; }).join('');
    var amount = keysMode ? R.keys : R.words;
    var fu3 = up ? '<div class="eh-formula eh-f3"><h3>How your result was worked out (UPSSSC rule)</h3><div class="eh-f3-g">' +
      '<div><span>1 · Words</span><p>' + (V.byWords ? 'Real words typed' : R.keys + ' ÷ 5') + ' = <b>' + n2(V.words) + '</b></p></div>' +
      '<div><span>2 · Penalty</span><p>' + n2(V.errs) + ' mistake' + (V.errs === 1 ? '' : 's') + ', 5 free = <b>' + n2(V.pen) + ' words</b></p></div>' +
      '<div><span>3 · Speed</span><p>' + n2(V.netWords) + ' ÷ ' + n2(V.mins) + ' = <b class="' + (V.pass ? 'ok' : 'no') + '">' + n2(V.wpm) + ' WPM</b></p></div>' +
      '</div><p class="eh-verdict-line">Result: ' + (V.pass ? '<b class="ok">Qualified</b> — speed is ' + V.need + ' WPM or more after the penalty.' : '<b class="no">Not Qualified</b> — speed after the penalty is below ' + V.need + ' WPM.') + '</p></div>' : '';
    var fu = up ? '<div class="eh-formula"><h3>How your result was worked out (UPSSSC rule)</h3><ol>' +
      (V.byWords ? '<li><b>Words typed</b> = real words you typed = <b>' + n2(V.words) + '</b></li>' : '<li><b>Words typed</b> = key depressions ÷ 5 = ' + R.keys + ' ÷ 5 = <b>' + n2(V.words) + '</b></li>') +
      '<li><b>Mistakes</b> = Full ' + R.full + ' + Half ' + R.half + ' ÷ 2 = <b>' + n2(V.errs) + '</b> (the first 5 are free)</li>' +
      '<li><b>Penalty</b> = ' + (V.errs > 5 ? '(' + n2(V.errs) + ' − 5) × 6 = <b>' + n2(V.pen) + ' words</b>' : '<b>0 words</b>, because mistakes are 5 or fewer') + '</li>' +
      '<li><b>Net words</b> = ' + n2(V.words) + ' − ' + n2(V.pen) + ' = <b>' + n2(V.netWords) + '</b></li>' +
      '<li><b>Speed</b> = net words ÷ minutes = ' + n2(V.netWords) + ' ÷ ' + n2(V.mins) + ' = <b>' + n2(V.wpm) + ' WPM</b>, needed ' + V.need + ' → ' + (V.pass ? '✔ done' : '✘ short') + '</li>' +
      '</ol><p class="eh-verdict-line">Result: ' + (V.pass ? '<b class="ok">Qualified</b> — speed is ' + V.need + ' WPM or more after the penalty.' : '<b class="no">Not Qualified</b> — speed after the penalty is below ' + V.need + ' WPM.') + '</p></div>' : '';
    var f = '<div class="eh-formula"><h3>How your result was worked out</h3><ol>' +
      '<li><b>Gross Speed</b> = words typed ÷ minutes = ' + R.words + ' ÷ ' + mins.toFixed(2) + ' = <b>' + R.gross + ' WPM</b></li>' +
      '<li><b>Mistakes</b> = Full ' + R.full + ' + Half ' + R.half + ' ÷ 2 = <b>' + errs + '</b></li>' +
      '<li><b>Net Speed</b> = (words − mistakes) ÷ minutes = (' + R.words + ' − ' + errs + ') ÷ ' + mins.toFixed(2) + ' = <b>' + R.net + ' WPM</b></li>' +
      '<li><b>Error %</b> = mistakes ÷ words × 100 = ' + errs + ' ÷ ' + (R.words || 0) + ' × 100 = <b>' + R.err + '%</b> (allowed ' + allowed + '%)</li>' +
      '<li><b>' + (keysMode ? 'Key depressions' : 'Words') + '</b>: you typed ' + amount + ', needed ' + X.target + ' → ' + (amount >= X.target ? '✔ done' : '✘ short') + '</li>' +
      '</ol><p class="eh-verdict-line">Result: ' + (R.pass ? '<b class="ok">Qualified</b> — target met and errors within the limit.' : '<b class="no">Not Qualified</b> — ' + (amount < X.target ? 'target not met' : '') + (amount < X.target && R.err > allowed ? ' and ' : '') + (R.err > allowed ? 'error ' + allowed + '% limit crossed' : '') + '.') + '</p></div>';
    var legend = '<p class="eh-legend"><span class="d-ok">Correct</span> <span class="d-sub">Wrong word (Full)</span> <span class="d-om">Missed word (Full)</span> <span class="d-add">Added word (Full)</span> <span class="d-skip">Skipped line</span> <span class="d-rest-k">Not typed</span> <span class="d-half">Half mistake</span></p>';
    var cmp = '<div class="eh-cmp-wrap"><div class="eh-cmp-tabs"><button type="button" class="on" data-v="two">Side by side</button><button type="button" data-v="one">Inline</button></div>' + legend +
      '<div class="eh-cmp-v" data-v="two">' + twoCol(ops) + '</div><div class="eh-cmp-v eh-diff" data-v="one" hidden>' + inline(ops) + '</div></div>';
    var sp = up ? n2(V.wpm) : R.net;
    var hero = '<div class="eh-score ' + (R.pass ? 'ok' : 'no') + '"><div><p class="eh-kicker">Performance Dashboard</p><h2>' + esc(X.name) + '</h2>' +
      '<p class="eh-score-sub">' + (R.title ? esc(R.title) : '') + (R.title && R.date ? ' · ' : '') + (R.date ? esc(R.date) : '') + '</p></div>' +
      '<div class="eh-score-n"><span>Net Speed</span><b>' + sp + '</b><em>WPM · needed ' + (up ? V.need : esc(eh_tgt(X, tgt))) + '</em></div>' +
      '<div class="eh-score-v">' + (R.pass ? '✔ Qualified' : '✘ Not Qualified') + '</div>' +
      '<p class="eh-score-rule">' + (up ? 'First 5 mistakes free, then 6 words cut for each extra mistake (wrong word + 5)' : 'Allowed error ' + allowed + '%') + '</p></div>';
    /* details, word check and working, organised as tables */
    var tr2 = function (list, n) { var h = ''; for (var i = 0; i < list.length; i += n) { h += '<tr>'; for (var j = i; j < i + n; j++) h += list[j] ? '<th>' + list[j][0] + '</th><td>' + list[j][1] + '</td>' : '<th></th><td></td>'; h += '</tr>'; } return h; };
    var tDet = '<h4 class="eh-tbl-h">Test details</h4><div class="eh-tbl-w"><table class="eh-tbl eh-t3 eh-kvt">' + tr2([['Typing Date', esc(R.date || '—')], ['Key Depression', R.total ? R.total : '—'], ['Time Duration', mm(R.dur || X.minutes)], ['Time Taken', mm(R.minutes)]], 2) + '</table></div>';
    var tWord = '<h4 class="eh-tbl-h">Word check</h4><div class="eh-tbl-w"><table class="eh-tbl eh-t4 eh-kvt">' + tr2([['Words Typed', R.words], ['Keystroke Errors', R.kerr], ['Backspace', R.backspaces], ['Pending Words', R.pending || 0], ['Missed words', c.om], ['Added words', c.add], ['Wrong words', c.sub], ['Space/Case/Punct/Order', c.space + ' / ' + c.case + ' / ' + c.punct + ' / ' + c.trans]], 4) + '</table></div>';
    var res = '<b class="' + (V.pass ? 'ok' : 'no') + '">';
    var tCalc = up ? '<h4 class="eh-tbl-h">How your result was worked out (UPSSSC rule)</h4><div class="eh-tbl-w"><table class="eh-tbl eh-calc"><thead><tr><th>Step</th><th>Rule</th><th>Working</th><th>Answer</th></tr></thead><tbody>' +
      '<tr><th>Words</th><td>' + (V.byWords ? 'real words typed' : 'key strokes ÷ 5') + '</td><td>' + (V.byWords ? n2(V.words) : R.keys + ' ÷ 5') + '</td><td><b>' + n2(V.words) + '</b></td></tr>' +
      '<tr><th>Mistakes</th><td>full + half ÷ 2</td><td>' + R.full + ' + ' + R.half + ' ÷ 2</td><td><b>' + n2(V.errs) + '</b></td></tr>' +
      '<tr><th>Penalty</th><td>first 5 free, then wrong word + 5 words each</td><td>' + (V.errs > 5 ? '(' + n2(V.errs) + ' − 5) × 6' : n2(V.errs) + ' ≤ 5') + '</td><td><b>' + n2(V.pen) + ' words</b></td></tr>' +
      '<tr><th>Net words</th><td>words − penalty</td><td>' + n2(V.words) + ' − ' + n2(V.pen) + '</td><td><b>' + n2(V.netWords) + '</b></td></tr>' +
      '<tr class="eh-calc-sp"><th>Speed</th><td>net words ÷ minutes</td><td>' + n2(V.netWords) + ' ÷ ' + n2(V.mins) + '</td><td>' + res + n2(V.wpm) + ' WPM</b></td></tr>' +
      '</tbody><tfoot><tr><td colspan="4">Result: ' + res + (V.pass ? 'Qualified' : 'Not Qualified') + '</b> — needed ' + V.need + ' WPM, got ' + n2(V.wpm) + ' WPM.</td></tr></tfoot></table></div>' : f;
    /* compact 4 x 2 card grid (one screen), title line on top */
    var cc = function (lab, val, cls, ic) { return '<div class="eh-cc ' + (cls || '') + '"><span>' + lab + '</span><b>' + val + '</b>' + (ic ? '<i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + ic + '</svg></i>' : '') + '</div>'; };
    var pc = R.pass ? 'ok' : 'no';
    var errsAll = up ? n2(V.errs) : n2((+R.full || 0) + (+R.half || 0) / 2);
    var grid = '<div class="eh-ihead"><h2>Performance Dashboard</h2>' + (R.name ? '<p class="eh-cand">Candidate: <b>' + esc(R.name) + '</b></p>' : '') + '<dl class="eh-info">' +
      '<div><dt>Exam Title</dt><dd>' + esc(X.name) + '</dd></div><div><dt>Total Key Strokes</dt><dd>' + (R.total || R.keys) + '</dd></div><div><dt>Typing Date</dt><dd>' + esc(R.date || '—') + '</dd></div>' +
      '<div><dt>Passage Title</dt><dd>' + esc(R.title || '—') + '</dd></div><div><dt>Time Duration</dt><dd>' + mm(R.dur || X.minutes) + '</dd></div><div><dt>Time Taken</dt><dd>' + mm(R.minutes) + '</dd></div>' +
      '</dl></div>' +
      '<div class="eh-cgrid">' +
      cc(up ? 'Total Keystrokes / Words Typed' : 'Key Depressions', up ? R.keys + ' / ' + n2(V.words) : R.keys, 'k', ICO[4]) +
      cc('Full Mistakes', R.full, '', ICO[5]) + cc('Half Mistakes', R.half, '', ICO[6]) +
      cc('Total Mistakes', errsAll + (up ? ' <small>/ 5 free</small>' : ''), up && V.errs > 5 ? 'warn' : '', ICO[3]) +
      cc('Gross Speed', (up ? n2(V.words / V.mins) : R.gross) + ' <small>WPM</small>', '', ICO[1]) + cc('Accuracy', R.acc + ' <small>%</small>', '', ICO[2]) +
      cc('Net Speed', sp + ' <small>WPM</small>', pc + ' big', ICO[0]) +
      cc('Result', R.pass ? '✔ Qualified' : '✘ Not Qualified', pc + ' res', '') + '</div>';
    var strip = up ? '<p class="eh-fstrip">🧮 <b>Net Speed</b> = (' + n2(V.words) + ' − ' + (V.errs > 5 ? '(' + n2(V.errs) + ' − 5) × 6' : '0') + ') ÷ ' + n2(V.mins) + ' = <b class="' + pc + '">' + n2(V.wpm) + ' WPM</b> <span>· first 5 mistakes free, then 6 words cut for each, needed ' + V.need + ' WPM</span></p>'
      : '<p class="eh-fstrip">🧮 <b>Net Speed</b> = (' + R.words + ' − ' + errsAll + ') ÷ ' + mins.toFixed(2) + ' = <b class="' + pc + '">' + R.net + ' WPM</b> <span>· allowed error ' + allowed + '%</span></p>';
    var ksw = up ? '<label class="eh-ksw"><input type="checkbox"' + (R.mode === 'words' ? '' : ' checked') + '> <span class="eh-ksw-t"></span> <b>Key Stroke Based Formula</b> <small>5 key strokes = 1 word · used for result and rank</small></label>' : '';
    return '<div class="eh-screen">' + grid + strip + '<p class="eh-scr-hint">⬇ Rank, comparison and more details below</p></div>' +
      '<div class="eh-dash-slot"></div>' + ksw +
      '<details class="eh-more"><summary>More details <small>Word check · full working</small></summary><div class="eh-more-b">' + tWord + tCalc + '</div></details>' +
      '<h3 class="eh-cmp-title">Detailed Comparison</h3>' + cmp;
  }
  function bindDash(root) {
    /* rank line and buttons sit right under the dashboard screen */
    var panel = root.parentNode, moving = panel ? [panel.querySelector('#eh-res-saved'), panel.querySelector('.eh-res-actions')] : [];
    var place = function () {
      var vis = [].filter.call(root.querySelectorAll('.eh-dash-slot'), function (x) { var v = x.closest('.eh-kv'); return !v || !v.hidden; })[0];
      if (vis) moving.forEach(function (m) { if (m) vis.appendChild(m); });
    };
    var sws = root.querySelectorAll('.eh-ksw input');
    [].forEach.call(sws, function (sw) { sw.addEventListener('change', function () {
      var on = sw.checked; [].forEach.call(sws, function (o) { o.checked = on; });
      root.querySelectorAll('.eh-kv').forEach(function (v) { v.hidden = (v.getAttribute('data-k') === 'keys') !== on; });
      place();
    }); });
    place();
    root.querySelectorAll('.eh-cmp-tabs button').forEach(function (b) {
      b.addEventListener('click', function () {
        root.querySelectorAll('.eh-cmp-tabs button').forEach(function (x) { x.classList.toggle('on', x === b); });
        root.querySelectorAll('.eh-cmp-v').forEach(function (v) { v.hidden = v.getAttribute('data-v') !== b.getAttribute('data-v'); });
      });
    });
  }
  window.EHEval = { verdict: verdict, dashboard: dashboard, bindDash: bindDash, lev: lev, compare: compare, stripP: stripP, inline: inline, twoCol: twoCol, counts: counts, mistakes: mistakes, esc: esc };
})();
