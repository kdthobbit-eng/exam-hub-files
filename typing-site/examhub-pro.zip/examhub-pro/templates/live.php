<?php
$S = eh_live_schedule();
$now = (int) wp_date('G') * 60 + (int) wp_date('i');
$sel = sanitize_title($_GET['exam'] ?? '');
$row = null; foreach ($S as $r) if ($r['exam']['slug'] === $sel) $row = $r;
$medal = ['🥇', '🥈', '🥉'];
global $wpdb;
get_header();
echo eh_member_nav('live');
if ($row):
    $L = $row; $open = $now >= $L['s'] && $now <= $L['e'];
    $board = eh_leaderboard($L['exam']['slug'], $L['date'], 25);
    $players = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . eh_table() . ' WHERE live_date = %s AND exam = %s', $L['date'], $L['exam']['slug']));
?>
<section class="eh-live-hero"><div class="wrap eh-live-hero-in">
  <div>
    <p class="muted small"><a href="<?php echo esc_url(home_url('/live-typing/')); ?>">← Live Typing schedule</a></p>
    <span class="eh-live-dot"><?php echo $open ? 'LIVE' : ($now < $L['s'] ? 'जल्द' : 'खत्म'); ?></span>
    <h1><?php echo esc_html($L['exam']['name']); ?></h1>
    <p class="lead">आज का पैसेज सबके लिए एक ही है। <?php echo esc_html($L['start'] . ' से ' . $L['end']); ?> के बीच टेस्ट दीजिए, Net Speed से ranking बनेगी।</p>
  </div>
  <div class="eh-live-cards">
    <div class="eh-lc"><span>आज का पैसेज</span><b><?php echo esc_html($L['passage']['title'] ?? '—'); ?></b><em><?php echo $L['lang'] === 'hi' ? 'Hindi' : 'English'; ?> · <?php echo esc_html(eh_target_label($L['exam'])); ?></em></div>
    <div class="eh-lc"><span>आज टेस्ट दिया</span><b><?php echo number_format_i18n($players); ?></b><em>लोगों ने</em></div>
    <div class="eh-lc dark"><span><?php echo $open ? 'टेस्ट बंद होने में' : ($now < $L['s'] ? 'टेस्ट खुलने में' : 'कल फिर'); ?></span><b id="eh-cd" data-s="<?php echo $open ? ($L['e'] - $now) * 60 : ($now < $L['s'] ? ($L['s'] - $now) * 60 : 0); ?>">--:--:--</b><em><?php echo esc_html($L['start'] . ' – ' . $L['end']); ?></em></div>
  </div>
</div></section>
<section class="wrap eh-section eh-live">
  <div><?php if ($open && $L['passage']):
      $eh_exam = $L['exam']; if ($eh_exam['lang'] !== 'hi') $eh_exam['lang'] = 'en';
      $eh_cfg = ['fixedPassage' => $L['passage']['id'], 'lockTime' => true, 'live' => $L['date']];
      include __DIR__ . '/_test-ui.php';
    else: ?>
      <div class="eh-panel eh-live-closed"><h2><?php echo $now < $L['s'] ? 'टेस्ट ' . esc_html($L['start']) . ' बजे खुलेगा' : 'आज का Live टेस्ट खत्म हो गया'; ?></h2>
      <p class="muted">तब तक इसी एग्ज़ाम की प्रैक्टिस कर लीजिए।</p>
      <a class="btn dark" href="<?php echo esc_url(home_url('/typing/' . $L['exam']['slug'] . '/')); ?>">Practice Test →</a></div>
    <?php endif; ?></div>
  <aside>
    <div class="eh-panel eh-rank">
      <div class="eh-rank-head"><h2>आज की Ranking</h2><span class="muted small" id="eh-rk-time">अपने-आप अपडेट</span></div>
      <div class="eh-podium" id="eh-podium">
        <?php for ($i = 0; $i < 3; $i++): $r = $board[$i] ?? null; ?>
          <div class="p p<?php echo $i + 1; ?>"><i><?php echo $medal[$i]; ?></i><b><?php echo $r ? esc_html(eh_display_name($r)) : '—'; ?></b><span><?php echo $r ? (int) $r['net'] . ' WPM' : 'खाली'; ?></span></div>
        <?php endfor; ?>
      </div>
      <ol class="eh-rk-list" id="eh-rk-list" start="4">
        <?php foreach (array_slice($board, 3) as $r): ?><li><span><?php echo esc_html(eh_display_name($r)); ?></span><b><?php echo (int) $r['net']; ?></b><em><?php echo esc_html($r['acc']); ?>%</em></li><?php endforeach; ?>
      </ol>
      <?php if (!$board): ?><p class="muted small" id="eh-rk-empty">अभी किसी ने टेस्ट नहीं दिया — पहली रैंक आपकी हो सकती है!</p><?php endif; ?>
    </div>
  </aside>
</section>
<script>
(function(){
  var cd=document.getElementById('eh-cd'),s=+cd.dataset.s;
  function t(){if(s<=0){cd.textContent='00:00:00';return}var h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;cd.textContent=[h,m,x].map(function(v){return(v<10?'0':'')+v}).join(':');s--;if(s===0)setTimeout(function(){location.reload()},1500)}
  t();setInterval(t,1000);
  var api='<?php echo esc_url_raw(add_query_arg(['date' => $L['date'], 'exam' => $L['exam']['slug']], rest_url('eh/v1/leaderboard'))); ?>',md=['🥇','🥈','🥉'];
  function esc(v){return String(v).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
  function load(){fetch(api,{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(rows){
    if(!Array.isArray(rows))return;
    document.getElementById('eh-podium').innerHTML=[0,1,2].map(function(i){var r=rows[i];return '<div class="p p'+(i+1)+'"><i>'+md[i]+'</i><b>'+(r?esc(r.name):'—')+'</b><span>'+(r?r.net+' WPM':'खाली')+'</span></div>'}).join('');
    document.getElementById('eh-rk-list').innerHTML=rows.slice(3,25).map(function(r){return '<li><span>'+esc(r.name)+'</span><b>'+r.net+'</b><em>'+r.acc+'%</em></li>'}).join('');
    var e=document.getElementById('eh-rk-empty');if(e&&rows.length)e.remove();
    document.getElementById('eh-rk-time').textContent='अपडेट: '+new Date().toLocaleTimeString('hi-IN',{hour:'2-digit',minute:'2-digit'});
  }).catch(function(){})}
  setInterval(load,30000);document.addEventListener('eh:saved',load);
})();
</script>
<?php else: ?>
<section class="wrap eh-section">
  <p class="muted small"><?php echo esc_html(wp_date('d/m/Y')); ?> · <?php echo esc_html(eh_opt('brand')); ?></p>
  <h1 class="eh-live-h">Live Typing — सबके साथ, एक ही समय पर</h1>
  <p class="muted">हर एग्ज़ाम का रोज़ एक तय समय पर Live टेस्ट होता है। सबको एक ही पैसेज मिलता है और Net Speed से उस दिन की ranking बनती है।</p>
  <div class="eh-chips eh-live-chips"><button type="button" class="on" data-f="">All</button>
    <?php $seen = []; foreach ($S as $r) { $k = strtoupper(strtok(preg_replace('/^(rrb|nta|bihar|army|air|delhi|uttarakhand|andhra|punjab|jharkhand|chhattisgarh|rajasthan|telangana|bombay|allahabad|mp)-/', '$1 ', $r['exam']['slug']), '-')); if (isset($seen[$k])) continue; $seen[$k] = 1; echo '<button type="button" data-f="' . esc_attr($k) . '">' . esc_html($k) . '</button>'; } ?>
  </div>
  <div class="eh-table-wrap"><table class="eh-table eh-live-table"><thead><tr><th>#</th><th>Exam</th><th>Passage</th><th>Language</th><th>Start</th><th>End</th><th>Status</th><th>Action</th></tr></thead><tbody>
  <?php foreach ($S as $i => $r):
      $k = strtoupper(strtok(preg_replace('/^(rrb|nta|bihar|army|air|delhi|uttarakhand|andhra|punjab|jharkhand|chhattisgarh|rajasthan|telangana|bombay|allahabad|mp)-/', '$1 ', $r['exam']['slug']), '-'));
      $st = $now < $r['s'] ? 'soon' : ($now <= $r['e'] ? 'live' : 'done');
      $url = add_query_arg('exam', $r['exam']['slug'], home_url('/live-typing/')); ?>
    <tr data-f="<?php echo esc_attr($k); ?>">
      <td><?php echo $i + 1; ?></td>
      <td><b><?php echo esc_html($r['exam']['name']); ?></b></td>
      <td class="small"><?php echo esc_html($r['passage']['title'] ?? '—'); ?><br><span class="muted"><?php echo $r['passage'] ? number_format_i18n($r['passage']['chars']) . ' key strokes' : ''; ?></span></td>
      <td><?php echo $r['lang'] === 'hi' ? 'Hindi' : 'English'; ?></td>
      <td><?php echo esc_html(gmdate('h:i A', $r['s'] * 60)); ?></td>
      <td><?php echo esc_html(gmdate('h:i A', $r['e'] * 60)); ?></td>
      <td><?php echo $st === 'live' ? '<span class="pill ok">● Live</span>' : ($st === 'soon' ? '<span class="pill">जल्द</span>' : '<span class="pill no">खत्म</span>'); ?></td>
      <td><a class="btn <?php echo $st === 'live' ? 'dark' : 'ghost'; ?> sm" href="<?php echo esc_url($url); ?>"><?php echo $st === 'live' ? 'Start →' : ($st === 'done' ? 'Result' : 'देखें'); ?></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table></div>
</section>
<script>
(function(){var bs=document.querySelectorAll('.eh-live-chips button'),rows=document.querySelectorAll('.eh-live-table tbody tr');
bs.forEach(function(b){b.addEventListener('click',function(){bs.forEach(function(x){x.classList.toggle('on',x===b)});var f=b.getAttribute('data-f');rows.forEach(function(r){r.style.display=!f||r.getAttribute('data-f')===f?'':'none'})})});})();
</script>
<?php endif; get_footer();
