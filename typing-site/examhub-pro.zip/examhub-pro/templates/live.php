<?php
$eh_days = eh_live_days();
$eh_day = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($_GET['ldate'] ?? '')) && in_array($_GET['ldate'], $eh_days, true) ? $_GET['ldate'] : '';
$eh_set = (($_GET['set'] ?? '') === '3284');
$S = eh_live_schedule($eh_set ? '3284' : $eh_day);
$now = (int) wp_date('G') * 60 + (int) wp_date('i');
$sel = sanitize_title($_GET['exam'] ?? '');
$pid = sanitize_key($_GET['p'] ?? ''); $kb = sanitize_key($_GET['kb'] ?? '');
if (strpos($pid, 'x3284his') === 0) $pid = 'x3284hie' . substr($pid, 8); /* old links from a cached list (ids were x3284hiS01..) */
$row = null; foreach ($S as $r) if (!$row && $r['exam']['slug'] === $sel && ($pid === '' || ($r['passage']['id'] ?? '') === $pid)) $row = $r;
if (!$row && strpos($pid, 'x3284') === 0) foreach (eh_live_schedule('3284') as $r) if (!$row && $r['exam']['slug'] === $sel && ($r['passage']['id'] ?? '') === $pid) $row = $r;
/* a passage of an older day still opens from its link */
if (!$row && $pid !== '') foreach ($eh_days as $d) { foreach (eh_live_schedule($d) as $r) if (!$row && $r['exam']['slug'] === $sel && ($r['passage']['id'] ?? '') === $pid) $row = $r; if ($row) break; }
$medal = ['🥇', '🥈', '🥉'];
global $wpdb;
/* passages this user has already typed in Live Typing: [passage id => best row] */
$eh_uid = get_current_user_id(); $eh_done = [];
if ($eh_uid) foreach ((array) $wpdb->get_results($wpdb->prepare('SELECT id, rkey, passage, exam, net, pass FROM ' . eh_table() . " WHERE user_id = %d AND live_date IS NOT NULL ORDER BY net ASC", $eh_uid), ARRAY_A) as $d) $eh_done[$d['exam'] . '|' . $d['passage']] = $d;
$eh_back = home_url(add_query_arg([]));
get_header();
echo eh_member_nav('live');
if ($row):
    $L = $row; $open = $now >= $L['s'] && $now <= $L['e'];
    $allday = !empty($L['allday']); $lp = sanitize_key($L['passage']['id'] ?? '');
    $board = eh_leaderboard($L['exam']['slug'], $L['date'], 25, 0, $lp);
    /* next passage in the same list (same language and level first), skipping ones already typed */
    $eh_list = $S; $eh_in = false; foreach ($eh_list as $r) if ($r['exam']['slug'] === $L['exam']['slug'] && ($r['passage']['id'] ?? '') === $lp) $eh_in = true;
    if (!$eh_in) $eh_list = eh_live_schedule(strpos($lp, 'x3284') === 0 ? '3284' : (string) ($L['news'] ?? ''));
    $eh_next = ''; $eh_at = -1; foreach ($eh_list as $i => $r) if ($r['exam']['slug'] === $L['exam']['slug'] && ($r['passage']['id'] ?? '') === $lp) $eh_at = $i;
    if ($eh_at >= 0) { $cnt = count($eh_list);
        foreach ([true, false] as $same) { for ($k = 1; $k < $cnt && !$eh_next; $k++) { $r = $eh_list[($eh_at + $k) % $cnt];
            if ($r['lang'] !== $L['lang'] || ($same && $r['level'] !== $L['level']) || isset($eh_done[$r['exam']['slug'] . '|' . ($r['passage']['id'] ?? '')])) continue;
            $q = ['exam' => $r['exam']['slug'], 'p' => $r['passage']['id']]; if (strpos($lp, 'x3284') === 0) $q['set'] = '3284'; if ($kb) $q['kb'] = $kb;
            $eh_next = add_query_arg($q, home_url('/live-typing/')); } if ($eh_next) break; } }
    $players = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . eh_table() . ' WHERE live_date = %s AND exam = %s AND passage = %s', $L['date'], $L['exam']['slug'], $lp));
?>
<section class="eh-live-hero"><div class="wrap eh-live-hero-in">
  <div>
    <p class="muted small"><a href="<?php echo esc_url(home_url('/live-typing/')); ?>">← All Live Typing tests</a></p>
    <span class="eh-live-dot"><?php echo $open ? 'LIVE' : ($now < $L['s'] ? 'Soon' : 'Closed'); ?></span>
    <h1><?php echo esc_html($L['exam']['name'] . (!empty($L['no']) ? ' · Passage ' . (int) $L['no'] . (!empty($L['level']) ? ' · ' . $L['level'] : '') : '')); ?></h1>
    <p class="lead"><?php echo $allday ? 'This passage is the same for everyone today and is open all day. Ranking is by net speed.' : 'Today’s passage is the same for everyone. Open from ' . esc_html($L['start'] . ' to ' . $L['end']) . '. Take the test in this window; ranking is by net speed.'; ?></p>
  </div>
  <div class="eh-live-cards">
    <div class="eh-lc"><span>Today’s passage</span><b><?php echo esc_html($L['passage']['title'] ?? '—'); ?></b><em><?php echo $L['lang'] === 'hi' ? 'Hindi' : 'English'; ?> · <?php echo !empty($L['level']) ? esc_html($L['level']) . ' · ' . number_format_i18n($L['chars']) . ' key strokes' : esc_html(eh_target_label($L['exam'])); ?></em></div>
    <div class="eh-lc"><span>Tests today</span><b><?php echo number_format_i18n($players); ?></b><em>people</em></div>
    <div class="eh-lc dark"><span><?php echo $open ? ($allday ? 'Time left today' : 'Closes in') : ($now < $L['s'] ? 'Opens in' : 'Back tomorrow'); ?></span><b id="eh-cd" data-s="<?php echo $open ? ($L['e'] - $now) * 60 : ($now < $L['s'] ? ($L['s'] - $now) * 60 : 0); ?>">--:--:--</b><em><?php echo $allday ? 'Open all day' : esc_html($L['start'] . ' – ' . $L['end']); ?></em></div>
  </div>
</div></section>
<section class="wrap eh-section eh-live">
  <div><?php $eh_mine = $eh_done[$L['exam']['slug'] . '|' . $lp] ?? null;
    if ($open && $L['passage'] && !$eh_uid): ?>
      <div class="eh-panel eh-live-lock"><span class="eh-live-lock-ic">🔒</span>
        <h2><?php echo strpos($lp, 'x3284') === 0 ? 'Log in to take UPSSSC 3284 Pattern Passage' : 'Log in to take Live Typing'; ?></h2>
        <p class="muted">Live Typing has a ranking, so each test is saved to your account. It is free and takes one minute.</p>
        <div class="eh-live-lock-btns"><a class="btn dark" href="<?php echo esc_url(eh_login_page_url($eh_back)); ?>">Log in →</a>
        <a class="btn ghost" href="<?php echo esc_url(add_query_arg('redirect_to', rawurlencode($eh_back), eh_signup_page_url())); ?>">New user? Sign up</a></div>
      </div>
    <?php elseif ($open && $L['passage'] && $eh_mine): ?>
      <div class="eh-panel eh-live-lock done"><span class="eh-live-lock-ic">✅</span>
        <h2>Attempted</h2>
        <p class="muted">You have already typed this passage. Your speed: <b><?php echo (int) $eh_mine['net']; ?> WPM</b> · <?php echo $eh_mine['pass'] ? 'Qualified' : 'Not qualified'; ?>. Each live passage can be typed once, so the ranking stays fair.</p>
        <div class="eh-live-lock-btns"><?php if ($eh_next): ?><a class="btn eh-next-btn" href="<?php echo esc_url($eh_next); ?>">अगला पैसेज →</a><?php endif; ?><a class="btn dark" href="<?php echo esc_url(eh_result_url($eh_mine['id'], $eh_mine['rkey'])); ?>">See my result →</a>
        <a class="btn ghost" href="<?php echo esc_url(home_url('/live-typing/')); ?>">Other passages</a></div>
      </div>
    <?php elseif ($open && $L['passage']):
      $eh_exam = $L['exam']; if ($eh_exam['lang'] !== 'hi') $eh_exam['lang'] = 'en';
      $eh_cfg = ['fixedPassage' => $L['passage']['id'], 'lockTime' => true, 'live' => $L['date']];
      if (!empty($L['plist'])) $eh_cfg['passages'] = $L['plist'];
      if ($L['lang'] === 'hi' && in_array($kb, ['krutidev', 'inscript'], true)) $eh_cfg['layout'] = $kb;
      include __DIR__ . '/_test-ui.php';
      if ($eh_next): ?><a id="eh-next-psg" class="btn eh-next-btn" href="<?php echo esc_url($eh_next); ?>">अगला पैसेज →</a>
      <script>(function(){var n=document.getElementById('eh-next-psg'),a=document.querySelector('#eh-result .eh-res-bottom')||document.querySelector('#eh-result .eh-res-actions');if(n&&a)a.insertBefore(n,a.firstChild);})();</script><?php endif;
    else: ?>
      <div class="eh-panel eh-live-closed"><h2><?php echo $now < $L['s'] ? 'Test opens at ' . esc_html($L['start']) : 'Today’s live test is over'; ?></h2>
      <p class="muted">Meanwhile, practise this exam.</p>
      <a class="btn dark" href="<?php echo esc_url(home_url('/typing/' . $L['exam']['slug'] . '/')); ?>">Practice Test →</a></div>
    <?php endif; ?></div>
  <aside>
    <div class="eh-panel eh-rank">
      <div class="eh-rank-head"><h2>Today’s ranking</h2><span class="muted small" id="eh-rk-time">Auto-updates</span></div>
      <div class="eh-podium" id="eh-podium">
        <?php for ($i = 0; $i < 3; $i++): $r = $board[$i] ?? null; ?>
          <div class="p p<?php echo $i + 1; ?>"><i><?php echo $medal[$i]; ?></i><b><?php echo $r ? esc_html(eh_display_name($r)) : '—'; ?></b><span><?php echo $r ? (int) $r['net'] . ' WPM' : 'Empty'; ?></span></div>
        <?php endfor; ?>
      </div>
      <ol class="eh-rk-list" id="eh-rk-list" start="4">
        <?php foreach (array_slice($board, 3) as $r): ?><li><span><?php echo esc_html(eh_display_name($r)); ?></span><b><?php echo (int) $r['net']; ?></b><em><?php echo esc_html($r['acc']); ?>%</em></li><?php endforeach; ?>
      </ol>
      <?php if (!$board): ?><p class="muted small" id="eh-rk-empty">No one has taken the test yet. The first rank can be yours.</p><?php endif; ?>
    </div>
  </aside>
</section>
<script>
(function(){
  var cd=document.getElementById('eh-cd'),s=+cd.dataset.s;
  function t(){if(s<=0){cd.textContent='00:00:00';return}var h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;cd.textContent=[h,m,x].map(function(v){return(v<10?'0':'')+v}).join(':');s--;if(s===0)setTimeout(function(){location.reload()},1500)}
  t();setInterval(t,1000);
  var api='<?php echo esc_url_raw(add_query_arg(['date' => $L['date'], 'exam' => $L['exam']['slug'], 'passage' => $lp], rest_url('eh/v1/leaderboard'))); ?>',md=['🥇','🥈','🥉'];
  function esc(v){return String(v).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
  function load(){fetch(api,{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(rows){
    if(!Array.isArray(rows))return;
    document.getElementById('eh-podium').innerHTML=[0,1,2].map(function(i){var r=rows[i];return '<div class="p p'+(i+1)+'"><i>'+md[i]+'</i><b>'+(r?esc(r.name):'—')+'</b><span>'+(r?r.net+' WPM':'Empty')+'</span></div>'}).join('');
    document.getElementById('eh-rk-list').innerHTML=rows.slice(3,25).map(function(r){return '<li><span>'+esc(r.name)+'</span><b>'+r.net+'</b><em>'+r.acc+'%</em></li>'}).join('');
    var e=document.getElementById('eh-rk-empty');if(e&&rows.length)e.remove();
    document.getElementById('eh-rk-time').textContent='Updated: '+new Date().toLocaleTimeString('hi-IN',{hour:'2-digit',minute:'2-digit'});
  }).catch(function(){})}
  setInterval(load,30000);document.addEventListener('eh:saved',load);
})();
</script>
<?php else:
  $allday = $S && !empty($S[0]['allday']); ?>
<section class="wrap eh-section">
  <?php if (!$allday): ?><p class="muted small"><?php echo esc_html(wp_date('d/m/Y')); ?> · <?php echo esc_html(eh_opt('brand_typing') ?: eh_opt('brand')); ?></p><?php endif; ?>
  <?php if ($allday): ?>
  <div class="eh-lt-head<?php echo $eh_set ? ' eh-lt-3284' : ''; ?>"><div class="eh-lt-top"><div class="eh-lt-title">
  <?php if ($eh_set): ?>
  <p class="eh-lt-kick"><span class="eh-lt-dot"></span> 3284 Pattern · <a href="<?php echo esc_url(home_url('/live-typing/')); ?>">← Live Typing</a></p>
  <h1 class="eh-live-h">UPSSSC 3284 Junior Assistant</h1>
  <p class="eh-lt-sub">Pattern Passage · सभी शिफ्टों के पैटर्न व परीक्षा केंद्र से मिली समीक्षा पर आधारित · English + हिंदी (Krutidev / Mangal)</p></div>
  <?php else: ?>
  <p class="eh-lt-kick"><span class="eh-lt-dot"></span> Live today · <?php echo esc_html(eh_opt('brand_typing') ?: eh_opt('brand')); ?></p>
  <h1 class="eh-live-h">UPSSSC Junior Assistant Live Typing</h1>
  <p class="eh-lt-sub">Same passage for everyone · open all day · ranking by net speed</p>
  <a class="eh-3284-cta" href="<?php echo esc_url(add_query_arg('set', '3284', home_url('/live-typing/'))); ?>">🔴 UPSSSC 3284 Junior Assistant Pattern Passage →<small>सभी शिफ्टों के पैटर्न व परीक्षा केंद्र से मिली समीक्षा पर आधारित</small></a></div>
  <?php endif; ?>
  <?php $eh_news = ''; foreach ($S as $x) if (!empty($x['news'])) $eh_news = $x['news'];
  $eh_fd = function ($d) { return date_i18n('j M Y', strtotime($d)); };
  $eh_cur = $eh_news ?: wp_date('Y-m-d'); $eh_ix = array_search($eh_cur, $eh_days, true);
  $eh_u = function ($d) use ($eh_days) { return $d === ($eh_days[0] ?? '') ? home_url('/live-typing/') : add_query_arg('ldate', $d, home_url('/live-typing/')); };
  $eh_newer = $eh_ix !== false && $eh_ix > 0 ? $eh_days[$eh_ix - 1] : ''; $eh_older = $eh_ix !== false && isset($eh_days[$eh_ix + 1]) ? $eh_days[$eh_ix + 1] : '';
  if ($eh_days && !$eh_set): ?>
  <div class="eh-dp" id="eh-dp" data-days="<?php echo esc_attr(implode(',', $eh_days)); ?>" data-cur="<?php echo esc_attr($eh_cur); ?>" data-base="<?php echo esc_url(home_url('/live-typing/')); ?>">
    <a class="eh-dp-nav<?php echo $eh_older ? '' : ' off'; ?>" <?php echo $eh_older ? 'href="' . esc_url($eh_u($eh_older)) . '"' : ''; ?> aria-label="Previous day">‹</a>
    <button type="button" class="eh-dp-btn" id="eh-dp-btn" aria-haspopup="true">
      <span class="eh-dp-ic">📅</span>
      <span class="eh-dp-t"><b><?php echo esc_html(date_i18n('j M Y', strtotime($eh_cur))); ?></b><small><?php echo $eh_cur === wp_date('Y-m-d') ? 'Today' : esc_html(date_i18n('l', strtotime($eh_cur))); ?></small></span>
      <span class="eh-dp-ar">▾</span>
    </button>
    <a class="eh-dp-nav<?php echo $eh_newer ? '' : ' off'; ?>" <?php echo $eh_newer ? 'href="' . esc_url($eh_u($eh_newer)) . '"' : ''; ?> aria-label="Next day">›</a>
    <?php if ($eh_ix !== 0): ?><a class="eh-dp-today" href="<?php echo esc_url(home_url('/live-typing/')); ?>">Today</a><?php endif; ?>
    <div class="eh-dp-pop" id="eh-dp-pop" hidden></div>
  </div>
  <?php endif; ?>
  </div><div class="eh-lt-bar">
  <?php $eh_lc = array_count_values(array_map(function ($r) { return $r['level'] ?? ''; }, $S)); ?>
  <?php if ($eh_set): $eh_lg = array_count_values(array_column($S, 'lang')); ?><p class="eh-dp-sum"><b><?php echo count($S); ?></b> passages · English <?php echo (int) ($eh_lg['en'] ?? 0); ?> · हिंदी <?php echo (int) ($eh_lg['hi'] ?? 0); ?></p><?php else: ?><p class="eh-dp-sum"><b><?php echo count($S); ?></b> passages<?php if ($eh_news): ?> ·<?php if (!empty($eh_lc['Super Hard'])): ?> <span class="eh-lvl superhard"><?php echo (int) $eh_lc['Super Hard']; ?> Super Hard</span><?php endif; ?> <span class="eh-lvl easy"><?php echo (int) ($eh_lc['Easy'] ?? 0); ?> Easy</span> <span class="eh-lvl moderate"><?php echo (int) ($eh_lc['Moderate'] ?? 0); ?> Moderate</span> <span class="eh-lvl hard"><?php echo (int) ($eh_lc['Hard'] ?? 0); ?> Hard</span> · English + Hindi<?php endif; ?></p><?php endif; ?>
  <script>
  (function () {
    var box = document.getElementById('eh-dp'); if (!box) return;
    var days = box.getAttribute('data-days').split(','), cur = box.getAttribute('data-cur'), base = box.getAttribute('data-base');
    var pop = document.getElementById('eh-dp-pop'), btn = document.getElementById('eh-dp-btn');
    var M = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var y = +cur.slice(0, 4), m = +cur.slice(5, 7) - 1;
    function z(n) { return (n < 10 ? '0' : '') + n; }
    function draw() {
      var first = new Date(y, m, 1).getDay(), n = new Date(y, m + 1, 0).getDate(), h = '<div class="eh-dp-h"><button type="button" data-s="-1">‹</button><b>' + M[m] + ' ' + y + '</b><button type="button" data-s="1">›</button></div><div class="eh-dp-g">';
      ['S', 'M', 'T', 'W', 'T', 'F', 'S'].forEach(function (d) { h += '<i>' + d + '</i>'; });
      for (var k = 0; k < first; k++) h += '<span></span>';
      for (var d = 1; d <= n; d++) {
        var id = y + '-' + z(m + 1) + '-' + z(d);
        h += days.indexOf(id) > -1 ? '<a class="' + (id === cur ? 'on' : '') + '" href="' + (id === days[0] ? base : base + '?ldate=' + id) + '">' + d + '</a>' : '<span class="na">' + d + '</span>';
      }
      pop.innerHTML = h + '</div><p>Dates in colour have passages.</p>';
    }
    btn.addEventListener('click', function (e) { e.stopPropagation(); if (pop.hidden) draw(); pop.hidden = !pop.hidden; });
    pop.addEventListener('click', function (e) { e.stopPropagation(); var s = e.target.getAttribute && e.target.getAttribute('data-s'); if (s) { m += +s; if (m < 0) { m = 11; y--; } if (m > 11) { m = 0; y++; } draw(); } });
    document.addEventListener('click', function () { pop.hidden = true; });
  })();
  </script>
  <div class="eh-chips eh-live-chips"><button type="button" class="on" data-f="">All</button><button type="button" data-f="en">English</button><button type="button" data-f="hi">Hindi</button></div>
  <div class="eh-chips eh-live-lv"><button type="button" class="on" data-l="">All levels</button><button type="button" class="lv-s" data-l="superhard">Super Hard</button><button type="button" class="lv-e" data-l="easy">Easy</button><button type="button" class="lv-m" data-l="moderate">Moderate</button><button type="button" class="lv-h" data-l="hard">Hard</button></div>
  <?php if ($eh_set): ?>
  <?php $eh_fn = count(array_filter(eh_passages('en'), function ($p) { return ($p['day'] ?? '') === 'full3284'; }));
  if ($eh_fn): $eh_fu = home_url('/typing/upsssc-assistants-english-typing-test/'); ?>
  <div class="eh-full" id="full-exam">
    <div class="eh-full-h"><span class="eh-full-badge">NEW</span><b>3284 Full Exam · English + हिंदी एक साथ</b>
    <span>परीक्षा की तरह पहले English (5 मिनट), Submit होते ही 15 सेकंड में हिंदी (5 मिनट) अपने आप शुरू · अंत में दोनों का एक साथ परिणाम · <?php echo (int) $eh_fn; ?> सेट</span></div>
    <div class="eh-full-tool" id="eh-full-tool" data-u="<?php echo esc_url($eh_fu); ?>" data-n="<?php echo (int) $eh_fn; ?>">
      <label><span>Set चुनें</span><select id="eh-ft-set"><?php for ($i = 1; $i <= $eh_fn; $i++) echo '<option value="' . $i . '">Set ' . $i . '</option>'; ?></select></label>
      <div class="eh-ft-kb"><span>हिंदी कीबोर्ड</span><label><input type="radio" name="eh-ft-kb" value="krutidev" checked> Krutidev</label><label><input type="radio" name="eh-ft-kb" value="inscript"> Mangal</label></div>
      <button type="button" class="eh-ft-go" id="eh-ft-go">Full Exam शुरू करें →</button>
    </div>
    <script>(function(){var t=document.getElementById('eh-full-tool');if(!t)return;var s=document.getElementById('eh-ft-set');
    try{var k=localStorage.getItem('eh_ftkb');if(k){var r=t.querySelector('input[value="'+JSON.parse(k)+'"]');if(r)r.checked=true;}}catch(e){}
    document.getElementById('eh-ft-go').addEventListener('click',function(){var n=+t.getAttribute('data-n'),v=+s.value,kb=t.querySelector('input[name=eh-ft-kb]:checked').value;
    try{localStorage.setItem('eh_ftkb',JSON.stringify(kb));}catch(e){}
    location.href=t.getAttribute('data-u')+'?full=1&fs='+v+'&kb='+kb;});})();</script>
  </div>
  <?php endif; ?>
  <div class="eh-3284-info">
    <div class="eh-3284-ih"><b>परीक्षा की जानकारी</b><span>UPSSSC 3284 Junior Assistant Typing · 13-15 नवंबर 2026 · सभी शिफ्टों के पैटर्न व परीक्षा केंद्र से मिली समीक्षा पर आधारित</span></div>
    <div class="eh-3284-grid">
      <div class="eh-3284-tile eh-3284-new"><i>🆕</i><div><span>15 Nov · English पैसेज</span><b>विषय: UPI, AI से जुड़ा · UPI पूरा CAPITAL · अंक जैसे 900 million · शुरू की 3 लाइन कठिन, बड़े शब्द · स्तर Moderate-Hard</b></div></div>
      <div class="eh-3284-tile eh-3284-new"><i>🆕</i><div><span>15 Nov · हिंदी पैसेज</span><b>कहानी जैसा, छोटे और सरल शब्द · अंक या स्पेशल कैरेक्टर लगभग नहीं · स्तर Easy</b></div></div>
      <div class="eh-3284-tile eh-3284-new"><i>📏</i><div><span>15 Nov · लाइन</span><b>एक लाइन में 40-42 शब्द · English लगभग 5 लाइन टाइप हुई (अभ्यर्थियों के अनुसार) · पहले English, फिर हिंदी</b></div></div>
      <div class="eh-3284-tile eh-3284-new"><i>🆕</i><div><span>14 Nov · English पैसेज</span><b>विषय: Investment, Mutual Fund, Silver ETF · पहला शब्द Investment · स्तर Moderate</b></div></div>
      <div class="eh-3284-tile eh-3284-new"><i>🆕</i><div><span>14 Nov · English में अंक</span><b>2025, 2026, 13310, करोड़ की राशि, कॉमा वाले बड़े नंबर · कुछ शब्द पूरे CAPITAL में (ETF)</b></div></div>
      <div class="eh-3284-tile eh-3284-new"><i>🆕</i><div><span>14 Nov · हिंदी पैसेज</span><b>विषय: आत्मा, माया, जड़-चेतन · केवल कॉमा और हाइफ़न, कोई अंक या स्पेशल कैरेक्टर नहीं · स्तर Easy</b></div></div>
      <div class="eh-3284-tile eh-3284-new"><i>🆕</i><div><span>14 Nov · स्क्रीन</span><b>गलत अक्षर तुरंत लाल · बैकस्पेस से केवल मौजूदा और पिछला शब्द · Demo के बाद चेकबॉक्स पर फॉन्ट छोटा-बड़ा</b></div></div>
      <div class="eh-3284-tile eh-3284-new"><i>📏</i><div><span>14 Nov · कितना टाइप हुआ</span><b>English लगभग 7 लाइन, हिंदी 6 से 9 लाइन (अभ्यर्थियों के अनुसार)</b></div></div>
      <div class="eh-3284-tile"><i>⌨️</i><div><span>कीबोर्ड</span><b>HP K100, सभी के लिए एक जैसा</b></div></div>
      <div class="eh-3284-tile"><i>🇬🇧</i><div><span>English पैसेज</span><b>विषय: नेताजी सुभाष चंद्र बोस · शब्द ज़्यादातर 5-6 अक्षर के</b></div></div>
      <div class="eh-3284-tile"><i>🇮🇳</i><div><span>हिंदी पैसेज (सुबह)</span><b>विषय: दीपावली</b></div></div>
      <div class="eh-3284-tile eh-3284-eve"><i>🌇</i><div><span>13 Nov · शाम की शिफ्ट (English)</span><b>पैसेज भारतीय सेना (Indian Army) से शुरू हुआ, एक जगह का नाम भी आया · स्तर Medium</b></div></div>
      <div class="eh-3284-tile eh-3284-eve"><i>🌇</i><div><span>13 Nov · शाम की शिफ्ट (हिंदी)</span><b>विषय: सन् 1947 ई0 का विभाजन, लाहौर से अमृतसर आए डॉ0 और उनकी माता, शरणार्थियों का निःशुल्क उपचार · स्तर Moderate से थोड़ा Hard · 1947 English अंकों में</b></div></div>
      <div class="eh-3284-tile"><i>✍️</i><div><span>शाम की शिफ्ट में ध्यान दें</span><b>कोलन/विसर्ग (थे: थी: किया:) कई जगह आया: Mangal में Shift + -, Krutidev में % · लाघव चिह्न की जगह जीरो: डॉ0, ई0 · कोई चंद्रबिंदु नहीं, Alt वाला कोई शब्द नहीं · कठिन शब्द: हृदयविदारक, चुनौतीपूर्ण, अनिश्चितताओं, औषधालय, ट्रॉमा सेंटर</b></div></div>
      <div class="eh-3284-tile"><i>🔤</i><div><span>पैसेज में आए शब्द</span><b>Jewellery, Precious, Education, Agitation, तारीख 01.10.1945</b></div></div>
      <div class="eh-3284-tile"><i>🔠</i><div><span>अक्षर</span><b>कुछ शब्द Capital में, बाकी small letters</b></div></div>
      <div class="eh-3284-tile"><i>🔐</i><div><span>Login</span><b>Roll No. / Registration No. और Password, टेस्ट से लगभग आधा घंटा पहले</b></div></div>
      <div class="eh-3284-tile"><i>▶️</i><div><span>Demo</span><b>असली टेस्ट से पहले लगभग 1 मिनट</b></div></div>
      <div class="eh-3284-tile"><i>🌐</i><div><span>भाषा</span><b>Krutidev या Mangal ऊपर से चुनें, भाषा Alt + Shift से बदलती है</b></div></div>
      <div class="eh-3284-tile"><i>🔎</i><div><span>Font</span><b>आकार छोटा</b></div></div>
      <div class="eh-3284-tile"><i>⏰</i><div><span>शिफ्ट</span><b>पहली शिफ्ट सुबह 8 बजे, गेट पर समय से पहले पहुंचें</b></div></div>
    </div>
  </div>
  <?php echo eh_video_3284('in-live'); ?>
  <?php endif; ?>
  </div></div>
  <?php else: ?>
  <h1 class="eh-live-h">Live Typing — same passage, same time, for everyone</h1>
  <p class="muted">Each exam has a live test at a fixed time every day. Everyone gets the same passage and the day's ranking is by net speed.</p>
  <div class="eh-chips eh-live-chips"><button type="button" class="on" data-f="">All</button><button type="button" data-f="en">English</button><button type="button" data-f="hi">Hindi</button></div>
  <div class="eh-chips eh-live-lv"><button type="button" class="on" data-l="">All levels</button><button type="button" class="lv-s" data-l="superhard">Super Hard</button><button type="button" class="lv-e" data-l="easy">Easy</button><button type="button" class="lv-m" data-l="moderate">Moderate</button><button type="button" class="lv-h" data-l="hard">Hard</button></div>
  <?php endif; ?>
  <div class="eh-table-wrap"><table class="eh-table eh-live-table"><thead><tr><th>#</th><th>Test</th><th>Level</th><th>Passage</th><th>Language</th><th>Time</th><th>Status</th><th>Start</th></tr></thead><tbody>
  <?php foreach ($S as $i => $r):
      $st = $now < $r['s'] ? 'soon' : ($now <= $r['e'] ? 'live' : 'done');
      $q = ['exam' => $r['exam']['slug']]; if (!empty($r['allday'])) $q['p'] = $r['passage']['id'];
      $url = add_query_arg($q, home_url('/live-typing/')); ?>
    <tr data-f="<?php echo esc_attr($r['lang']); ?>" data-lv="<?php echo esc_attr(str_replace(' ', '', strtolower($r['level'] ?? ''))); ?>" class="<?php echo isset($eh_done[$r['exam']['slug'] . '|' . ($r['passage']['id'] ?? '')]) ? 'eh-row-att' : ''; ?>">
      <td><?php echo $i + 1; ?></td>
      <td><b><?php echo esc_html($r['exam']['name']); ?></b><?php if (!empty($r['no'])) echo '<br><span class="muted small">Passage ' . (int) $r['no'] . '</span>'; ?></td>
      <td><?php echo !empty($r['level']) ? '<span class="eh-lvl ' . esc_attr(str_replace(' ', '', strtolower($r['level']))) . '">' . esc_html($r['level']) . '</span>' : '—'; ?></td>
      <td class="small"><?php echo esc_html($r['passage']['title'] ?? '—'); ?><br><span class="muted"><?php echo $r['passage'] ? number_format_i18n($r['chars'] ?? $r['passage']['chars']) . ' key strokes' : ''; ?></span></td>
      <td><?php echo $r['lang'] === 'hi' ? 'Hindi<br><span class="muted small">Krutidev / Mangal Inscript</span>' : 'English'; ?></td>
      <td><?php echo !empty($r['allday']) ? 'All day' : esc_html(gmdate('h:i A', $r['s'] * 60) . ' – ' . gmdate('h:i A', $r['e'] * 60)); ?><?php if (!empty($r['passage']['added']) && ($at = strtotime($r['passage']['added'])) && time() - ($at - 19800) < 3 * 86400) echo '<small class="eh-new-at">🆕 ' . esc_html(date('d M, h:i A', $at)) . '</small>'; ?></td>
      <?php $mine = $eh_done[$r['exam']['slug'] . '|' . ($r['passage']['id'] ?? '')] ?? null; ?>
      <td><?php echo $mine ? '<span class="pill eh-att">✓ Attempted</span>' : ($st === 'live' ? '<span class="pill ok">● Open</span>' : ($st === 'soon' ? '<span class="pill">Soon</span>' : '<span class="pill no">Closed</span>')); ?></td>
      <td class="eh-live-act"><?php if ($mine): ?>
          <a class="btn ghost sm" href="<?php echo esc_url(eh_result_url($mine['id'], $mine['rkey'])); ?>"><?php echo (int) $mine['net']; ?> WPM · Result</a>
        <?php elseif ($st === 'live' && !$eh_uid): ?>
          <a class="btn dark sm" href="<?php echo esc_url(eh_login_page_url($url)); ?>">🔒 Log in to start</a>
        <?php elseif ($st === 'live' && $r['lang'] === 'hi'): ?>
          <a class="btn dark sm" href="<?php echo esc_url(add_query_arg('kb', 'krutidev', $url)); ?>">Krutidev →</a>
          <a class="btn dark sm" href="<?php echo esc_url(add_query_arg('kb', 'inscript', $url)); ?>">Mangal →</a>
        <?php else: ?>
          <a class="btn <?php echo $st === 'live' ? 'dark' : 'ghost'; ?> sm" href="<?php echo esc_url($url); ?>"><?php echo $st === 'live' ? 'Start →' : ($st === 'done' ? 'Result' : 'View'); ?></a>
        <?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table></div>
  <div class="eh-live-pg" id="eh-live-pg"></div>
</section>
<script>
(function(){var bl=document.querySelectorAll('.eh-live-lv button'),l='',bs=document.querySelectorAll('.eh-live-chips button'),rows=[].slice.call(document.querySelectorAll('.eh-live-table tbody tr')),pg=document.getElementById('eh-live-pg'),per=20,f='',page=1;
function draw(){var list=rows.filter(function(r){return (!f||r.getAttribute('data-f')===f)&&(!l||r.getAttribute('data-lv')===l);}),n=Math.max(1,Math.ceil(list.length/per));if(page>n)page=n;
rows.forEach(function(r){r.style.display='none';});list.forEach(function(r,i){if(i>=(page-1)*per&&i<page*per)r.style.display='';});
if(!pg)return;if(n<2){pg.innerHTML='';return;}var h='<button type="button" data-p="'+(page-1)+'"'+(page<2?' disabled':'')+'>← Prev</button>';
for(var k=1;k<=n;k++)h+='<button type="button" data-p="'+k+'" class="'+(k===page?'on':'')+'">'+k+'</button>';
pg.innerHTML=h+'<button type="button" data-p="'+(page+1)+'"'+(page>=n?' disabled':'')+'>Next →</button><span>Page '+page+' of '+n+'</span>';}
if(pg)pg.addEventListener('click',function(e){var p=e.target.getAttribute&&e.target.getAttribute('data-p');if(!p||e.target.disabled)return;page=+p;draw();var t=document.querySelector('.eh-live-chips');if(t)t.scrollIntoView({behavior:'smooth',block:'start'});});
bs.forEach(function(b){b.addEventListener('click',function(){bs.forEach(function(x){x.classList.toggle('on',x===b)});f=b.getAttribute('data-f');page=1;draw();});});bl.forEach(function(b){b.addEventListener('click',function(){bl.forEach(function(x){x.classList.toggle('on',x===b)});l=b.getAttribute('data-l');page=1;draw();});});draw();})();
</script>
<?php endif; get_footer();
